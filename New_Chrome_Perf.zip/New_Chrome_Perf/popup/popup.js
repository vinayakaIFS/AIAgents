'use strict';
const $ = (id) => document.getElementById(id);
const send = (msg) => chrome.runtime.sendMessage(msg);
let baselineStats = null;
let settings = null;
let lastSummarySig = '';

async function loadBaselines() {
  const list = await Store.listBaselines();
  const active = await Store.get('activeBaseline', null);
  const sel = $('baselineSel');
  sel.innerHTML = '<option value="">(no baseline)</option>' + list.sort((a, b) => b.createdAt - a.createdAt)
    .map((b) => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join('');
  sel.value = active && list.some((b) => b.id === active) ? active : '';
  await loadBaselineStats(sel.value);
}

async function loadBaselineStats(id) {
  baselineStats = null;
  if (!id) return;
  const b = await Store.getBaseline(id);
  if (b) baselineStats = new Map(PerfStats.baselineStats(b).transactions.map((t) => [t.name, t]));
}

function escapeHtml(s) { return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

async function refresh() {
  const st = await send({ cmd: 'status' });
  if (!st || !st.ok) return;
  const rec = st.state.recording;
  $('state').textContent = rec ? 'Recording' : 'Idle';
  $('state').className = 'pill ' + (rec ? 'rec' : 'idle');
  $('idleBox').hidden = rec;
  $('recBox').hidden = !rec;
  if (rec && st.session) {
    $('recName').textContent = st.session.name;
    const mins = Math.floor((Date.now() - st.session.startedAt) / 60000);
    $('recInfo').textContent = `${st.session.txCount} transactions · ${mins} min`;
    const c = st.current;
    $('currentTx').textContent = c ? `▶ ${c.name} — ${c.requests} requests (${c.inflight} open)` :
      (st.state.nextName ? `Next transaction will be named "${st.state.nextName}"` : 'Waiting for the next action…');
    if (st.replay) {
      const r = st.replay;
      $('currentTx').textContent = `↻ Rerun of "${r.flowName}": iteration ${r.iteration || 1}/${r.iterations}, step ${r.step || 0}/${r.steps} — ${r.label || ''}` + (c ? ` · ▶ ${c.name}` : '');
    }
    document.querySelectorAll('#recBox .row').forEach((row) => { row.hidden = !!st.replay; });
    $('stopBtn').textContent = st.replay ? '■ Stop rerun' : '■ Stop recording';
    const manual = c && c.type === 'manual';
    $('manualBtn').textContent = manual ? 'End' : 'Start';
    $('manualName').disabled = manual;
  }
  renderRecent(st.recent || []);
  if (rec && st.session && baselineStats) {
    const sig = st.session.id + ':' + st.session.txCount + ':' + $('baselineSel').value;
    if (sig !== lastSummarySig) { lastSummarySig = sig; renderLiveSummary(st.session.id); }
  } else { lastSummarySig = ''; $('liveSummary').textContent = ''; }
}

function renderRecent(recent) {
  const metric = (settings && settings.compareMetric) || 'p95';
  const tb = document.querySelector('#recent tbody');
  if (!recent.length) { tb.innerHTML = '<tr><td colspan="5" class="empty">No transactions recorded yet</td></tr>'; return; }
  tb.innerHTML = recent.map((t) => {
    let cmp = '<span class="same">–</span>';
    const b = baselineStats && baselineStats.get(t.name);
    if (b && b[metric]) {
      const pct = ((t.duration - b[metric]) / b[metric]) * 100;
      const cls = pct >= settings.thresholdPct && t.duration - b[metric] >= settings.thresholdMs ? 'up'
        : pct <= -settings.thresholdPct && b[metric] - t.duration >= settings.thresholdMs ? 'down' : 'same';
      cmp = `<span class="${cls}" title="baseline ${metric} ${PerfStats.fmtMs(b[metric])}">${PerfStats.fmtPct(pct)}</span>`;
    } else if (baselineStats) cmp = '<span class="same">new</span>';
    return `<tr><td>${t.seq || ''}</td><td class="name" title="${escapeHtml(t.name)}">${escapeHtml(t.name)}</td>` +
      `<td class="num">${PerfStats.fmtMs(t.duration)}</td><td class="num">${t.reqCount}${t.errors ? ' ⚠' : ''}</td><td class="num">${cmp}</td></tr>`;
  }).join('');
}

async function renderLiveSummary(sessionId) {
  const s = await Store.getSession(sessionId);
  if (!s) return;
  const cur = PerfStats.aggregateTransactions(s.transactions);
  const res = PerfStats.compare(Array.from(baselineStats.values()), cur, { metric: settings.compareMetric, thresholdPct: settings.thresholdPct, thresholdMs: settings.thresholdMs });
  const c = res.counts;
  $('liveSummary').innerHTML = `<span>Session vs baseline (${res.metric}):</span><b class="improved">${c.improved} improved</b>` +
    `<b class="degraded">${c.degraded} degraded</b><span>${c.unchanged} unchanged</span><span>${c.new} new</span>`;
}

$('startBtn').onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  await send({ cmd: 'start', tabId: tab.id, url: tab.url, name: $('sessionName').value.trim(), reload: $('reload').value || null });
  $('sessionName').value = '';
  refresh();
};
$('stopBtn').onclick = async () => { await send({ cmd: 'stop' }); refresh(); };
$('nextBtn').onclick = async () => { await send({ cmd: 'nextName', name: $('nextName').value.trim() }); $('nextName').value = ''; refresh(); };
$('manualBtn').onclick = async () => {
  if ($('manualBtn').textContent === 'End') await send({ cmd: 'manualEnd' });
  else await send({ cmd: 'manualStart', name: $('manualName').value.trim() || 'Manual transaction' });
  $('manualName').value = '';
  refresh();
};
$('baselineSel').onchange = async () => {
  await Store.set('activeBaseline', $('baselineSel').value || null);
  await loadBaselineStats($('baselineSel').value);
  refresh();
};
$('dashBtn').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });

(async () => {
  settings = await Store.getSettings();
  await loadBaselines();
  await refresh();
  setInterval(refresh, 1000);
})();
