'use strict';
/* Flows & reruns tab: library of recorded flows, their runs (recording + reruns), trend and steps. */

const RUN_STATUS_ORDER = { running: 0, failed: 1, errors: 2, stopped: 3, ok: 4 };
const fmtDur = (ms) => (ms == null ? '–' : ms < 60000 ? Math.round(ms / 1000) + ' s' : Math.floor(ms / 60000) + ' min ' + Math.round((ms % 60000) / 1000) + ' s');

async function renderFlows() {
  state.flows = (await Store.listFlows()).sort((a, b) => (b.lastRunAt || b.createdAt) - (a.lastRunAt || a.createdAt));
  state.replayState = await Store.get('replayState', null);
  renderReplayBanner();
  if (state.flowId && !state.flows.some((f) => f.id === state.flowId)) state.flowId = null;
  if (!state.flowId && state.flows.length) state.flowId = state.flows[0].id;

  renderTable('flowsTable', [
    { key: 'name', label: 'Flow', cls: 'name', html: (f) => `<span title="${esc(f.name)}">${esc(f.name)}</span>`, csv: (f) => f.name },
    { key: 'steps', label: 'Steps', num: true },
    { key: 'runs', label: 'Runs', num: true },
    { key: 'lastRunAt', label: 'Last run', fmt: (v) => (v ? fmtTime(v) : '–') },
    { key: 'lastStatus', label: 'Status', html: (f) => (f.lastStatus ? statusBadgeRun(f.lastStatus) : '') },
    { key: 'createdAt', label: 'Created', fmt: (v) => fmtTime(v) },
    { key: 'startUrl', label: 'Start URL', cls: 'name' }
  ], state.flows, {
    defaultSort: { key: 'lastRunAt', dir: 'desc' },
    empty: 'No flows yet. Record a session from the toolbar popup: when you stop, it is saved here automatically.',
    rowAttrs: (f) => `class="clickable ${f.id === state.flowId ? 'selected' : ''}" data-id="${f.id}"`
  });
  $('flowsTable').querySelectorAll('tr.clickable').forEach((tr) => {
    tr.onclick = () => { if (state.flowId !== tr.dataset.id) { state.flowId = tr.dataset.id; state.stepsDirty = false; state.trendSel = null; } renderFlows(); };
  });
  await renderFlowDetail();
}

function statusBadgeRun(s) { return `<span class="badge ${esc(s)}">${esc(s)}</span>`; }

function renderReplayBanner() {
  const b = $('replayBanner');
  const r = state.replayState;
  if (!r) { b.hidden = true; return; }
  b.hidden = false;
  if (r.active) {
    b.className = 'banner';
    b.innerHTML = `<b>↻ Rerunning "${esc(r.flowName)}"</b><span>iteration ${r.iteration || 1}/${r.iterations} · step ${r.step || 0}/${r.steps}</span>` +
      `<span class="muted">${esc(r.label || '')}</span>${r.errors ? `<span class="up">${r.errors} failed step(s)</span>` : ''}<span class="spacer"></span><button id="stopRerunBtn" class="danger-outline">Stop rerun</button>`;
    $('stopRerunBtn').onclick = () => send({ cmd: 'stopFlow' });
  } else if (r.endedAt && Date.now() - r.endedAt < 10 * 60000) {
    b.className = 'banner ' + (r.status === 'ok' ? 'done-ok' : 'done-bad');
    b.innerHTML = `<b>Last rerun of "${esc(r.flowName)}": ${statusBadgeRun(r.status)}</b><span class="muted">${esc(r.error || '')}</span><span class="spacer"></span><button id="hideBanner">Dismiss</button>`;
    $('hideBanner').onclick = async () => { await Store.set('replayState', null); };
  } else b.hidden = true;
}

async function renderFlowDetail() {
  const box = $('flowDetail');
  if (!state.flowId) { box.hidden = true; return; }
  const flow = await Store.getFlow(state.flowId);
  if (!flow) { box.hidden = true; return; }
  if (!state.stepsDirty || !state.flow || state.flow.id !== flow.id) state.flow = flow;
  else state.flow.runs = flow.runs; // keep unsaved step edits
  box.hidden = false;
  $('fdName').textContent = flow.name;
  $('fdInfo').textContent = `${flow.steps.length} steps · start ${flow.startUrl} · created ${fmtTime(flow.createdAt)}`;
  const busy = !!(state.replayState && state.replayState.active) || !!(state.recState && state.recState.recording);
  $('rrRun').disabled = busy;
  $('rrRun').title = busy ? 'A recording or rerun is in progress' : '';

  // Runs with measurements
  const runs = flow.runs.slice().sort((a, b) => a.startedAt - b.startedAt);
  const sessions = await Promise.all(runs.map((r) => Store.getSession(r.sessionId)));
  const refIdx = runs.findIndex((r) => r.sessionId === flow.referenceSessionId);
  const ref = refIdx >= 0 && sessions[refIdx] ? P.aggregateTransactions(sessions[refIdx].transactions) : null;
  const opts = { metric: state.settings.compareMetric, thresholdPct: state.settings.thresholdPct, thresholdMs: state.settings.thresholdMs };
  const rows = runs.map((r, i) => {
    const s = sessions[i];
    const agg = s ? P.aggregateTransactions(s.transactions) : [];
    const txs = s ? s.transactions.filter((t) => t.status === 'closed') : [];
    const row = { i: i + 1, run: r, sid: r.sessionId, name: s ? s.name : (r.sessionName || r.sessionId) + ' (session deleted)', kind: r.kind,
      startedAt: r.startedAt, duration: (s && s.endedAt ? s.endedAt : r.endedAt || Date.now()) - r.startedAt,
      iterations: r.iterations || 1, status: r.status || 'ok', steps: r.stepsTotal ? `${r.stepsOk}/${r.stepsTotal}` : '', txCount: txs.length,
      avg: txs.length ? txs.reduce((a, t) => a + t.duration, 0) / txs.length : null, agg, exists: !!s, isRef: r.sessionId === flow.referenceSessionId };
    if (ref && s && !row.isRef) {
      const c = P.compare(ref, agg, opts);
      const common = c.rows.filter((x) => x.base && x.cur);
      const sb = common.reduce((a, x) => a + x.bv, 0), sc = common.reduce((a, x) => a + x.cv, 0);
      row.improved = c.counts.improved; row.degraded = c.counts.degraded; row.totalPct = sb ? ((sc - sb) / sb) * 100 : null;
    }
    return row;
  });
  renderTable('runsTable', [
    { key: 'i', label: '#', num: true },
    { key: 'name', label: 'Run', cls: 'name', html: (r) => `${r.isRef ? '<span title="Reference run for comparisons">★ </span>' : ''}<span title="${esc(r.name)}">${esc(r.name)}</span>`, csv: (r) => r.name },
    { key: 'kind', label: 'Kind', html: (r) => statusBadgeRun(r.kind) },
    { key: 'startedAt', label: 'Started', fmt: (v) => fmtTime(v) },
    { key: 'duration', label: 'Duration', num: true, fmt: fmtDur },
    { key: 'iterations', label: 'Iter.', num: true },
    { key: 'status', label: 'Status', html: (r) => `<span title="${esc((r.run.error || '') + (r.run.errors && r.run.errors.length ? '\n' + r.run.errors.map((e) => `iter ${e.iteration} step ${e.step}: ${e.error}`).join('\n') : ''))}">${statusBadgeRun(r.status)}</span>`,
      sortVal: (r) => RUN_STATUS_ORDER[r.status], csv: (r) => r.status + (r.run.error ? ': ' + r.run.error : '') },
    { key: 'steps', label: 'Steps ok', num: true },
    { key: 'txCount', label: 'Transactions', num: true },
    { key: 'avg', label: 'Avg tx', num: true, fmt: P.fmtMs },
    { key: 'totalPct', label: `vs ★ (${opts.metric})`, num: true, fmt: P.fmtPct, cls: (r) => (r.totalPct > opts.thresholdPct ? 'up' : r.totalPct < -opts.thresholdPct ? 'down' : ''), title: 'Change of the summed metric over transactions present in both runs' },
    { key: 'improved', label: 'Improved', num: true, cls: () => 'down' },
    { key: 'degraded', label: 'Degraded', num: true, cls: (r) => (r.degraded ? 'up' : '') },
    { key: 'act', label: '', noCsv: true, html: (r) => (r.exists ? `<button class="mini" data-act="view" data-sid="${r.sid}">View</button>` +
      (r.isRef ? '' : `<button class="mini" data-act="compare" data-sid="${r.sid}" title="Compare with the ★ reference run">Compare</button><button class="mini" data-act="ref" data-sid="${r.sid}" title="Make this the reference run">★</button>`) +
      `<button class="mini" data-act="baseline" data-sid="${r.sid}" title="Save this run as a baseline">Baseline</button>` : '') +
      (r.kind === 'rerun' && r.status !== 'running' ? `<button class="mini" data-act="remove" data-sid="${r.sid}" title="Remove from this flow (the session is kept)">✕</button>` : '') }
  ], rows, { defaultSort: { key: 'startedAt', dir: 'desc' }, empty: 'No runs' });
  $('runsTable').querySelectorAll('button[data-act]').forEach((b) => { b.onclick = (e) => { e.stopPropagation(); runAction(b.dataset.act, b.dataset.sid, flow, sessions, runs); }; });

  renderTrend(rows.filter((r) => r.exists), ref);
  renderSteps();
}

async function runAction(act, sid, flow, sessions, runs) {
  const s = sessions[runs.findIndex((r) => r.sessionId === sid)];
  if (act === 'view' || act === 'compare') {
    state.selected = new Set([sid]);
    state.expanded.clear();
    if (act === 'compare') {
      const refS = sessions[runs.findIndex((r) => r.sessionId === flow.referenceSessionId)];
      if (!refS) return toast('The reference run session no longer exists');
      state.tempBaseline = P.buildBaseline(`★ ${refS.name}`, [refS]);
      state.tempBaseline.id = '__temp';
      state.baselineId = '__temp';
      state.cmpSel = null;
      await loadBaselines();
    }
    await loadIndex(); await loadData();
    state.tab = act === 'view' ? 'summary' : 'compare';
    renderTab();
    window.scrollTo(0, 0);
  } else if (act === 'ref') {
    await Store.updateFlow(flow.id, (f) => { f.referenceSessionId = sid; });
    toast('Reference run changed');
  } else if (act === 'baseline') {
    const name = prompt('Baseline name', `${flow.name} – ${s.name}`);
    if (!name) return;
    const b = P.buildBaseline(name, [s]);
    await Store.saveBaseline(b);
    if (!(await Store.get('activeBaseline', null))) await Store.set('activeBaseline', b.id);
    toast(`Baseline "${name}" saved`);
  } else if (act === 'remove') {
    if (!confirm('Remove this run from the flow? Its session stays in the sessions list.')) return;
    await Store.updateFlow(flow.id, (f) => { f.runs = f.runs.filter((r) => r.sessionId !== sid); });
  }
}

function renderTrend(rows, ref) {
  const metric = $('trendMetric').value;
  const names = [];
  rows.forEach((r) => r.agg.forEach((a) => { if (!names.includes(a.name)) names.push(a.name); }));
  if (!state.trendSel || state.trendFor !== state.flowId) {
    state.trendFor = state.flowId;
    const base = ref || (rows[0] && rows[0].agg) || [];
    state.trendSel = new Set(base.slice().sort((a, b) => b.p95 - a.p95).slice(0, 8).map((a) => a.name));
  }
  $('trendPick').innerHTML = names.map((n) => `<label title="${esc(n)}"><input type="checkbox" data-n="${esc(n)}" ${state.trendSel.has(n) ? 'checked' : ''}>` +
    `<span style="color:${colorFor(n)}">■</span><span class="t">${esc(n)}</span></label>`).join('');
  $('trendPick').querySelectorAll('input').forEach((cb) => {
    cb.onchange = () => { if (cb.checked) state.trendSel.add(cb.dataset.n); else state.trendSel.delete(cb.dataset.n); renderTrend(rows, ref); };
  });
  const series = names.filter((n) => state.trendSel.has(n)).map((n) => ({
    name: n, color: colorFor(n),
    points: rows.map((r, i) => { const a = r.agg.find((x) => x.name === n); return a ? { x: i + 1, y: a[metric], tip: `${r.name}\n${metric}: ${P.fmtMs(a[metric])} (n=${a.count})` } : null; }).filter(Boolean)
  }));
  const el = $('trendChart');
  el.innerHTML = rows.length < 2 && !series.some((s) => s.points.length) ? '<div class="chart-empty">Rerun the flow to see a trend</div>'
    : CH.line({ width: chartWidth(el), height: 320, series, integerX: true, xFmt: (v) => '#' + Math.round(v), xLabel: 'Run (oldest → newest, matches # in the runs table)',
      yLabel: `${metric} (ms)`, fmt: (v) => P.fmtMs(v).replace(' ms', ''), empty: 'Tick transactions above' });
}

function renderSteps() {
  const flow = state.flow;
  const rows = flow.steps.map((s, i) => Object.assign({ i: i + 1, idx: i, text: Flows.stepText(s), locator: s.sel ? s.sel.selectors[0] : '' }, s));
  renderTable('stepsTable', [
    { key: 'i', label: '#', num: true },
    { key: 'enabled', label: 'Run', noCsv: true, html: (r) => `<input type="checkbox" data-step="${r.idx}" ${r.enabled !== false ? 'checked' : ''}>` },
    { key: 'kind', label: 'Kind', html: (r) => typeBadge(r.kind) },
    { key: 'text', label: 'Step', cls: 'name', html: (r) => `<span title="${esc(r.text)}">${esc(r.text)}</span>` },
    { key: 'txName', label: 'Transaction', cls: 'name', html: (r) => `<span title="${esc(r.txName || '')}">${esc(r.txName || (r.kind === 'navigate' ? '(named from the page)' : ['input', 'manualEnd', 'manualStart'].includes(r.kind) ? '' : '(no network)'))}</span>` },
    { key: 'locator', label: 'Locator', cls: 'sel', html: (r) => `<span title="${esc(r.sel ? r.sel.selectors.join('\n') + (r.sel.text ? '\ntext: ' + r.sel.text : '') : '')}">${esc(r.locator)}</span>` },
    { key: 'value', label: 'Value', cls: 'name' },
    { key: 'think', label: 'Think (ms)', num: true, html: (r) => `<input class="think" type="number" min="0" step="100" data-think="${r.idx}" value="${r.think || 0}">` }
  ], rows, { defaultSort: { key: 'i', dir: 'asc' }, empty: 'This flow has no steps' });
  $('stepsTable').querySelectorAll('input[data-step]').forEach((cb) => { cb.onchange = () => { flow.steps[+cb.dataset.step].enabled = cb.checked; markDirty(); }; });
  $('stepsTable').querySelectorAll('input[data-think]').forEach((inp) => { inp.onchange = () => { flow.steps[+inp.dataset.think].think = Math.max(0, Number(inp.value) || 0); markDirty(); }; });
  $('stepsMsg').textContent = state.stepsDirty ? 'Unsaved changes' : '';
}
function markDirty() { state.stepsDirty = true; $('stepsMsg').textContent = 'Unsaved changes'; }

/* ---------------- actions ---------------- */

$('saveStepsBtn').onclick = async () => {
  if (!state.flow) return;
  const steps = state.flow.steps;
  await Store.updateFlow(state.flow.id, (f) => { f.steps = steps; });
  state.stepsDirty = false;
  toast('Steps saved');
};

$('rrThink').onchange = () => { $('rrThinkMsWrap').hidden = $('rrThink').value !== 'fixed'; };

$('rrRun').onclick = async () => {
  if (!state.flowId) return;
  if (state.stepsDirty && !confirm('Rerun without saving the step changes?')) return;
  const res = await send({ cmd: 'runFlow', flowId: state.flowId, opts: {
    iterations: Number($('rrIter').value) || 1, think: $('rrThink').value, thinkMs: Number($('rrThinkMs').value) || 0,
    cache: $('rrCache').value, stopOnError: $('rrStopOnError').checked, closeTab: $('rrCloseTab').checked } });
  if (!res || !res.ok) return toast('Rerun not started: ' + ((res && res.error) || 'no response'));
  toast('Rerun started in a new tab. Leave that tab alone until it finishes.');
};

$('saveFlowBtn').onclick = async () => {
  if (state.sessions.length !== 1) return toast('Tick exactly one session on the left');
  const s = state.sessions[0];
  if (s.replay) return toast('This session is already a rerun of a flow');
  if (!s.steps || !s.steps.length) return toast('This session was recorded before step capture existed, so it cannot be rerun');
  const f = Flows.build(s, $('flowName').value.trim() || s.name);
  await Store.saveFlow(f);
  $('flowName').value = '';
  state.flowId = f.id;
  toast(`Flow "${f.name}" saved with ${f.steps.length} steps`);
  renderFlows();
};

$('fdRename').onclick = async () => {
  if (!state.flowId) return;
  const n = prompt('Flow name', state.flow.name);
  if (!n) return;
  await Store.updateFlow(state.flowId, (f) => { f.name = n; });
};
$('fdDelete').onclick = async () => {
  if (!state.flowId || !confirm(`Delete flow "${state.flow.name}"? Its run sessions are kept. This cannot be undone.`)) return;
  await Store.deleteFlow(state.flowId);
  state.flowId = null;
  renderFlows();
};
$('fdExport').onclick = () => {
  if (!state.flow) return;
  download(`flow-${state.flow.name.replace(/[^\w.-]+/g, '_')}.json`, JSON.stringify({ format: 'txperf', version: 1, flows: [state.flow] }, null, 1));
};
$('exportFlowsBtn').onclick = async () => {
  const list = await Promise.all(state.flows.map((f) => Store.getFlow(f.id)));
  download(`txperf-flows-${fileStamp()}.json`, JSON.stringify({ format: 'txperf', version: 1, exportedAt: Date.now(), flows: list.filter(Boolean) }, null, 1));
};
$('importFlows').onchange = async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    const flows = data.flows || (data.steps && data.startUrl ? [data] : []);
    let n = 0;
    for (const f of flows) if (f.id && Array.isArray(f.steps)) { f.runs = f.runs || []; await Store.saveFlow(f); n++; }
    toast(`Imported ${n} flow(s)`);
    renderFlows();
  } catch (err) { toast('Import failed: ' + err.message); }
};
$('trendMetric').onchange = () => renderFlows();
$('trendAll').onclick = () => { document.querySelectorAll('#trendPick input').forEach((cb) => state.trendSel.add(cb.dataset.n)); renderFlows(); };
$('trendNone').onclick = () => { state.trendSel.clear(); renderFlows(); };
