'use strict';
/* Builds a self-contained HTML report (inline CSS + SVG charts, no scripts). */
(function (root) {
  const P = PerfStats, CH = Charts, esc = CH.esc;
  const W = 1100;

  const CSS = `
  :root{--fg:#202124;--muted:#5f6368;--line:#e0e3e7;--card:#f6f8fa;--good:#1e8e3e;--bad:#d93025;
    --good-bg:#e6f4ea;--ni-bg:#fef7e0;--poor-bg:#fce8e6;--chart-axis:#9aa0a6;--chart-grid:#eceff1;--chart-text:#5f6368;--chart-label:#202124}
  body{font:13px "Segoe UI",system-ui,sans-serif;color:var(--fg);margin:0;background:#fff}
  .wrap{max-width:1160px;margin:0 auto;padding:24px}
  h1{font-size:22px;margin:0 0 4px} h2{font-size:17px;margin:28px 0 8px;padding-bottom:4px;border-bottom:2px solid var(--line)}
  h3{font-size:14px;margin:16px 0 6px} .muted{color:var(--muted)} .small{font-size:11px}
  table{border-collapse:collapse;width:100%;font-size:12px;margin:6px 0}
  th,td{padding:4px 7px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
  th{background:var(--card);font-weight:600} td.num,th.num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
  td.name{max-width:520px;word-break:break-word}
  .kpis{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0}
  .kpi{border:1px solid var(--line);border-radius:8px;padding:8px 12px;min-width:130px}
  .kpi .v{font-size:19px;font-weight:600} .kpi .l{font-size:11px;color:var(--muted);text-transform:uppercase}
  .improved{color:var(--good)} .degraded{color:var(--bad)}
  .badge{display:inline-block;padding:1px 7px;border-radius:9px;font-size:11px;font-weight:600}
  .b-improved{background:var(--good-bg);color:var(--good)} .b-degraded{background:var(--poor-bg);color:var(--bad)}
  .b-unchanged{background:var(--card);color:var(--muted)} .b-new{background:#e8f0fe;color:#1a73e8} .b-missing{background:var(--ni-bg);color:#b06000}
  td.good{background:var(--good-bg)} td.ni{background:var(--ni-bg)} td.poor{background:var(--poor-bg)}
  .chart{max-width:100%;height:auto} .chart-empty{color:var(--muted);padding:12px}
  @media print{h2{page-break-before:auto} .chart{page-break-inside:avoid}}`;

  function table(cols, rows) {
    if (!rows.length) return '<p class="muted">No data.</p>';
    const h = cols.map((c) => `<th class="${c.num ? 'num' : ''}">${esc(c.label)}</th>`).join('');
    const b = rows.map((r) => '<tr>' + cols.map((c) => {
      const v = c.html ? c.html(r) : esc(c.fmt ? c.fmt(r[c.key], r) : (r[c.key] == null ? '' : r[c.key]));
      const cls = (c.num ? 'num ' : '') + (c.cls ? (typeof c.cls === 'function' ? c.cls(r) || '' : c.cls) : '');
      return `<td class="${cls}">${v}</td>`;
    }).join('') + '</tr>').join('');
    return `<table><thead><tr>${h}</tr></thead><tbody>${b}</tbody></table>`;
  }
  const kpi = (l, v, cls) => `<div class="kpi"><div class="v ${cls || ''}">${v}</div><div class="l">${esc(l)}</div></div>`;
  const badge = (s) => `<span class="badge b-${s}">${esc(s)}</span>`;

  function build(ctx) {
    const { sessions, txs, segs, baseline, compare } = ctx;
    const colorFor = ctx.colorFor || ((n, i) => CH.color(i || 0));
    const agg = P.aggregateTransactions(txs);
    const all = P.summarize(txs.map((t) => t.duration));
    const reqs = txs.reduce((s, t) => s + (t.reqCount || 0), 0);
    const errs = txs.reduce((s, t) => s + (t.errors || 0), 0);
    let h = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
      <title>Transaction performance report</title><style>${CSS}</style></head><body><div class="wrap">`;
    h += `<h1>Transaction performance report</h1><div class="muted">Generated ${esc(new Date().toLocaleString())} · Transaction Perf Recorder</div>`;

    h += '<h2>Sessions</h2>' + table([
      { key: 'name', label: 'Session', cls: 'name' },
      { key: 'startedAt', label: 'Started', fmt: (v) => new Date(v).toLocaleString() },
      { key: 'endedAt', label: 'Ended', fmt: (v) => (v ? new Date(v).toLocaleString() : 'recording') },
      { key: 'n', label: 'Transactions', num: true },
      { key: 'startUrl', label: 'Start URL', cls: 'name' }
    ], sessions.map((s) => Object.assign({}, s, { n: (s.transactions || []).filter((t) => t.status === 'closed').length })));

    h += '<div class="kpis">' + kpi('Transactions executed', txs.length) + kpi('Distinct transactions', agg.length) + kpi('HTTP requests', reqs.toLocaleString()) +
      kpi('Failed requests', errs, errs ? 'degraded' : '') + kpi('Average', P.fmtMs(all.avg)) + kpi('95th percentile', P.fmtMs(all.p95)) + kpi('Page views', segs.length) + '</div>';

    // Transactions
    h += '<h2>Transaction response times</h2><p class="muted small">End-to-end: from the user action (or navigation start) until the load event has fired and the network has gone quiet. Percentiles use the nearest-rank method.</p>';
    h += table([
      { key: 'i', label: '#', num: true },
      { key: 'name', label: 'Transaction', cls: 'name' },
      { key: 'type', label: 'Type', fmt: (v) => (v === 'navigation' ? 'page' : v) },
      { key: 'count', label: 'Count', num: true },
      { key: 'avg', label: 'Average', num: true, fmt: P.fmtMs },
      { key: 'p95', label: '95th pct', num: true, fmt: P.fmtMs },
      { key: 'p50', label: 'Median', num: true, fmt: P.fmtMs },
      { key: 'min', label: 'Min', num: true, fmt: P.fmtMs },
      { key: 'max', label: 'Max', num: true, fmt: P.fmtMs },
      { key: 'std', label: 'Std dev', num: true, fmt: P.fmtMs },
      { key: 'avgReqs', label: 'Avg req', num: true, fmt: (v) => P.fmtNum(v, 1) },
      { key: 'errors', label: 'Errors', num: true }
    ], agg.map((a, i) => Object.assign({ i: i + 1 }, a)));
    h += '<h3>Average vs 95th percentile</h3>' + CH.hbar({ width: W, categories: agg.map((a) => a.name), fmt: (v) => P.fmtMs(v),
      series: [{ name: 'Average', color: '#4e79a7', values: agg.map((a) => a.avg) }, { name: '95th percentile', color: '#f28e2b', values: agg.map((a) => a.p95) }] });
    const top = agg.slice().sort((a, b) => b.p95 - a.p95).slice(0, 12);
    h += `<h3>Response time per execution${agg.length > 12 ? ' (12 slowest transactions by 95th pct)' : ''}</h3>` + CH.line({ width: W, height: 360, yLabel: 'Response time (ms)', xLabel: 'Execution #',
      fmt: (v) => P.fmtMs(v).replace(' ms', ''),
      series: top.map((a) => ({ name: a.name, color: colorFor(a.name), points: txs.filter((t) => t.name === a.name).sort((x, y) => x.start - y.start).map((t, i) => ({ x: i + 1, y: t.duration })) })) });

    // Comparison
    if (baseline && compare) {
      const r = compare, c = r.tx.counts;
      h += `<h2>Comparison with baseline "${esc(baseline.name)}"</h2><p class="muted small">Baseline created ${esc(new Date(baseline.createdAt).toLocaleString())} from ${esc(baseline.sourceSessions.map((s) => s.name).join(', '))}. ` +
        `Metric: ${esc(r.o.metric)}. Improved / degraded = change of at least ${r.o.thresholdPct}% and ${r.o.thresholdMs} ms.</p>`;
      h += '<div class="kpis">' + kpi('Improved', c.improved, 'improved') + kpi('Degraded', c.degraded, 'degraded') + kpi('Unchanged', c.unchanged) + kpi('New', c.new) + kpi('Missing', c.missing) + '</div>';
      h += CH.stack({ width: W, parts: ['improved', 'degraded', 'unchanged', 'new', 'missing'].map((k) => ({ label: k, value: c[k], color: CH.STATUS[k] })) });
      const rows = r.tx.rows.slice().sort((a, b) => (b.pct == null ? -1e9 : b.pct) - (a.pct == null ? -1e9 : a.pct));
      h += table([
        { key: 'name', label: 'Transaction', cls: 'name' },
        { key: 'b', label: 'Base #', num: true, html: (x) => (x.base ? x.base.count : '–') },
        { key: 'ba', label: 'Base avg', num: true, html: (x) => P.fmtMs(x.base && x.base.avg) },
        { key: 'bp', label: 'Base 95th', num: true, html: (x) => P.fmtMs(x.base && x.base.p95) },
        { key: 'c', label: 'Cur #', num: true, html: (x) => (x.cur ? x.cur.count : '–') },
        { key: 'ca', label: 'Cur avg', num: true, html: (x) => P.fmtMs(x.cur && x.cur.avg) },
        { key: 'cp', label: 'Cur 95th', num: true, html: (x) => P.fmtMs(x.cur && x.cur.p95) },
        { key: 'delta', label: 'Δ', num: true, fmt: (v) => (v == null ? '–' : (v > 0 ? '+' : '') + P.fmtMs(v)) },
        { key: 'pct', label: 'Δ %', num: true, fmt: P.fmtPct, cls: (x) => (x.status === 'degraded' ? 'degraded' : x.status === 'improved' ? 'improved' : '') },
        { key: 'status', label: 'Status', html: (x) => badge(x.status) }
      ], rows);
      const common = rows.filter((x) => x.base && x.cur);
      h += `<h3>Baseline vs current (${esc(r.o.metric)})</h3>` + CH.hbar({ width: W, categories: common.map((x) => x.name), fmt: (v) => P.fmtMs(v),
        series: [{ name: 'Baseline', color: '#9aa0a6', values: common.map((x) => x.bv) },
          { name: 'Current', legendColor: '#4e79a7', color: (i) => (common[i].status === 'degraded' ? CH.STATUS.degraded : common[i].status === 'improved' ? CH.STATUS.improved : '#4e79a7'), values: common.map((x) => x.cv) }] });
      h += '<h3>Change (%)</h3>' + CH.diverging({ width: W, items: common.map((x) => ({ label: x.name, value: x.pct, color: CH.STATUS[x.status] })) });
      const reqRows = r.req.rows.filter((x) => x.base && x.cur && x.status !== 'unchanged').sort((a, b) => b.delta - a.delta).slice(0, 30);
      if (reqRows.length) {
        h += '<h3>Requests that changed most</h3>' + table([
          { key: 'name', label: 'Request', cls: 'name' },
          { key: 'bv', label: 'Base', num: true, fmt: P.fmtMs }, { key: 'cv', label: 'Current', num: true, fmt: P.fmtMs },
          { key: 'delta', label: 'Δ', num: true, fmt: (v) => (v > 0 ? '+' : '') + P.fmtMs(v) }, { key: 'pct', label: 'Δ %', num: true, fmt: P.fmtPct },
          { key: 'status', label: 'Status', html: (x) => badge(x.status) }], reqRows);
      }
    }

    // Web Vitals
    const vit = P.aggregateVitals(segs);
    h += '<h2>Web Vitals per page</h2><p class="muted small">p75 per page. Thresholds (good / poor): TTFB 800 / 1800 ms, FCP 1.8 / 3 s, LCP 2.5 / 4 s, CLS 0.1 / 0.25, INP 200 / 500 ms, TBT 200 / 600 ms. ' +
      'Route changes (SPA) only have CLS, INP and TBT measured from the route change.</p>';
    const vc = (k) => ({ key: k + '_p75', label: P.VITALS[k].label, num: true, fmt: (v) => P.fmtVital(k, v), cls: (r) => P.rate(k, r[k + '_p75']) || '' });
    h += table([
      { key: 'page', label: 'Page', cls: 'name' },
      { key: 'kind', label: 'Kind', fmt: (v) => (v === 'soft' ? 'route change' : 'page load') },
      { key: 'visits', label: 'Views', num: true },
      vc('ttfb'), vc('fcp'), vc('lcp'), vc('cls'), vc('inp'), vc('tbt'),
      { key: 'dcl_avg', label: 'DCL avg', num: true, fmt: P.fmtMs }, { key: 'load_avg', label: 'Load avg', num: true, fmt: P.fmtMs }
    ], vit);
    if (baseline && ctx.baseStats && ctx.baseStats.vitals.length) {
      const bm = new Map(ctx.baseStats.vitals.map((v) => [v.page + '|' + v.kind, v]));
      const rows = vit.filter((v) => bm.has(v.page + '|' + v.kind)).map((v) => ({ v, b: bm.get(v.page + '|' + v.kind) }));
      if (rows.length) {
        const cell = (k) => ({ key: k, label: P.VITALS[k].label, num: true, cls: (x) => P.rate(k, x.v[k + '_p75']) || '',
          html: (x) => `${P.fmtVital(k, x.b[k + '_p75'])} → <b>${P.fmtVital(k, x.v[k + '_p75'])}</b>` });
        h += '<h3>Web Vitals vs baseline (p75, baseline → current)</h3>' + table([{ key: 'p', label: 'Page', cls: 'name', html: (x) => esc(x.v.page) },
          { key: 'k', label: 'Kind', html: (x) => (x.v.kind === 'soft' ? 'route change' : 'page load') }].concat(['ttfb', 'fcp', 'lcp', 'cls', 'inp', 'tbt'].map(cell)), rows);
      }
    }
    const hard = vit.filter((v) => v.kind === 'hard');
    if (hard.length) h += '<h3>Loading metrics per page (p75)</h3>' + CH.hbar({ width: W, categories: hard.map((a) => a.page), fmt: (v) => P.fmtMs(v),
      series: [{ name: 'TTFB', color: '#76b7b2', values: hard.map((a) => a.ttfb_p75) }, { name: 'FCP', color: '#4e79a7', values: hard.map((a) => a.fcp_p75) },
        { name: 'LCP', color: '#f28e2b', values: hard.map((a) => a.lcp_p75) }, { name: 'Load', color: '#b07aa1', values: hard.map((a) => a.load_avg) }] });

    // Flow
    h += '<h2>Session flow</h2>';
    for (const s of sessions) {
      const list = txs.filter((t) => t._sid === s.id).sort((a, b) => a.start - b.start);
      h += `<h3>${esc(s.name)}</h3>` + table([
        { key: 'seq', label: '#', num: true, html: (t) => String(list.indexOf(t) + 1) },
        { key: 'start', label: 'Time', fmt: (v) => new Date(v).toLocaleTimeString() },
        { key: 'type', label: 'Type', fmt: (v) => (v === 'navigation' ? 'page' : v) },
        { key: 'name', label: 'Transaction', cls: 'name' },
        { key: 'duration', label: 'Response time', num: true, fmt: P.fmtMs },
        { key: 'reqCount', label: 'Requests', num: true },
        { key: 'errors', label: 'Errors', num: true }
      ], list);
    }

    // Slowest requests
    const ra = P.aggregateRequests(txs).sort((a, b) => b.p95 - a.p95).slice(0, 30);
    h += '<h2>Slowest requests (by 95th pct)</h2>' + table([
      { key: 'key', label: 'Request', cls: 'name' }, { key: 'count', label: 'Count', num: true },
      { key: 'avg', label: 'Average', num: true, fmt: P.fmtMs }, { key: 'p95', label: '95th pct', num: true, fmt: P.fmtMs },
      { key: 'max', label: 'Max', num: true, fmt: P.fmtMs }, { key: 'errors', label: 'Errors', num: true }], ra);

    return h + '</div></body></html>';
  }

  root.TxReport = { build };
})(typeof globalThis !== 'undefined' ? globalThis : this);
