'use strict';
/* Transaction Perf Dashboard */
const P = PerfStats, CH = Charts;
const $ = (id) => document.getElementById(id);
const esc = CH.esc;

const state = {
  index: [], selected: new Set(), sessions: [], txs: [], segs: [], orphans: [],
  baselines: [], baselineId: null, baseline: null, baseStats: null, activeBaseline: null,
  tab: 'summary', sort: {}, tables: {}, chartSel: null, cmpSel: null, cmpSelFor: null,
  expanded: new Set(), settings: null, recState: null, colorOf: new Map(),
  tempBaseline: null, flows: [], flowId: null, flow: null, stepsDirty: false, trendSel: null, trendFor: null, replayState: null
};

/* ---------------- helpers ---------------- */

function toast(msg) {
  let t = document.querySelector('.toast');
  if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._h);
  t._h = setTimeout(() => t.classList.remove('show'), 2600);
}

function download(name, text, type) {
  const url = URL.createObjectURL(new Blob([text], { type: type || 'application/json' }));
  const a = document.createElement('a');
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

const fileStamp = () => new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
const fmtTime = (t) => new Date(t).toLocaleString();
const fmtOffset = (ms) => { const s = ms / 1000; const m = Math.floor(s / 60); return `${m}:${(s - m * 60).toFixed(1).padStart(4, '0')}`; };
const typeBadge = (t) => `<span class="badge type">${esc(t === 'navigation' ? 'page' : t)}</span>`;
const statusBadge = (s) => `<span class="badge ${s}">${esc(s)}</span>`;
const chartWidth = (el) => Math.max(480, (el.clientWidth || 900) - 18);
const send = (msg) => chrome.runtime.sendMessage(msg);

function colorFor(name) {
  if (!state.colorOf.has(name)) state.colorOf.set(name, CH.color(state.colorOf.size));
  return state.colorOf.get(name);
}

/* Sortable table. cols: [{key, label, num, fmt(v,r), html(r), cls, sortVal(r), csv(r)}] */
function renderTable(id, cols, rows, opts) {
  opts = opts || {};
  const el = $(id);
  const srt = state.sort[id] || opts.defaultSort || null;
  const data = rows.slice();
  if (srt) {
    const c = cols.find((x) => x.key === srt.key);
    if (c) {
      const get = c.sortVal || ((r) => r[c.key]);
      data.sort((a, b) => {
        const x = get(a), y = get(b);
        if (x == null && y == null) return 0;
        if (x == null) return 1;
        if (y == null) return -1;
        return (x < y ? -1 : x > y ? 1 : 0) * (srt.dir === 'asc' ? 1 : -1);
      });
    }
  }
  state.tables[id] = { cols, rows: data };
  if (!data.length) { el.innerHTML = `<div class="empty">${esc(opts.empty || 'No data')}</div>`; return data; }
  const shown = opts.limit ? data.slice(0, opts.limit) : data;
  const head = cols.map((c) => `<th data-k="${c.key}" class="${c.num ? 'num' : ''} ${srt && srt.key === c.key ? 'sorted' + (srt.dir === 'asc' ? ' asc' : '') : ''}" title="${esc(c.title || '')}">${esc(c.label)}</th>`).join('');
  const body = shown.map((r, i) => {
    let tr = `<tr ${opts.rowAttrs ? opts.rowAttrs(r, i) : ''}>` + cols.map((c) => {
      const v = c.html ? c.html(r) : esc(c.fmt ? c.fmt(r[c.key], r) : (r[c.key] == null ? '' : r[c.key]));
      const cls = (c.num ? 'num ' : '') + (c.cls ? (typeof c.cls === 'function' ? c.cls(r) || '' : c.cls) : '');
      return `<td class="${cls}">${v}</td>`;
    }).join('') + '</tr>';
    if (opts.after) tr += opts.after(r, i) || '';
    return tr;
  }).join('');
  const more = opts.limit && data.length > opts.limit ? `<div class="empty">Showing ${opts.limit} of ${data.length} rows (CSV has all)</div>` : '';
  el.innerHTML = `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>${more}`;
  el.querySelectorAll('th').forEach((th) => {
    th.onclick = () => {
      const k = th.dataset.k;
      const cur = state.sort[id] || opts.defaultSort;
      state.sort[id] = { key: k, dir: cur && cur.key === k && cur.dir === 'desc' ? 'asc' : 'desc' };
      renderTab();
    };
  });
  return data;
}

function tableCsv(id) {
  const t = state.tables[id];
  if (!t) return;
  const q = (v) => { const s = v == null ? '' : String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  const cols = t.cols.filter((c) => !c.noCsv);
  const lines = [cols.map((c) => q(c.label)).join(',')];
  t.rows.forEach((r) => lines.push(cols.map((c) => {
    let v = c.csv ? c.csv(r) : r[c.key];
    if (typeof v === 'number') v = Math.round(v * 1000) / 1000;
    return q(v);
  }).join(',')));
  download(`${id}-${fileStamp()}.csv`, lines.join('\r\n'), 'text/csv');
}

/* ---------------- data loading ---------------- */

async function loadIndex() {
  state.index = (await Store.listSessions()).sort((a, b) => b.startedAt - a.startedAt);
  state.recState = await Store.get('recState', null);
  const ids = new Set(state.index.map((s) => s.id));
  for (const id of Array.from(state.selected)) if (!ids.has(id)) state.selected.delete(id);
  if (!state.selected.size && state.index.length) state.selected.add(state.index[0].id);
  renderSessions();
}

async function loadData() {
  const list = await Promise.all(Array.from(state.selected).map((id) => Store.getSession(id)));
  state.sessions = list.filter(Boolean).sort((a, b) => a.startedAt - b.startedAt);
  state.txs = []; state.segs = []; state.orphans = [];
  for (const s of state.sessions) {
    for (const t of s.transactions || []) {
      if (t.status !== 'closed') continue;
      t._sid = s.id; t._session = s.name; t._offset = t.start - s.startedAt;
      state.txs.push(t);
    }
    for (const v of Object.values(s.vitals || {})) {
      if (v.pre) continue;
      v._session = s.name;
      state.segs.push(v);
    }
    (s.unattributed || []).forEach((r) => state.orphans.push(r));
  }
  state.txs.forEach((t) => colorFor(t.name));
  const n = state.sessions.length;
  $('selInfo').textContent = n ? `${n} session${n > 1 ? 's' : ''} · ${state.txs.length} transactions · ${state.segs.length} page views` : 'No session selected';
}

async function loadBaselines() {
  state.baselines = (await Store.listBaselines()).sort((a, b) => b.createdAt - a.createdAt);
  state.activeBaseline = await Store.get('activeBaseline', null);
  if (!(state.baselineId === '__temp' && state.tempBaseline) && !state.baselines.some((b) => b.id === state.baselineId)) {
    state.baselineId = state.baselines.some((b) => b.id === state.activeBaseline) ? state.activeBaseline : (state.baselines[0] && state.baselines[0].id) || null;
  }
  const sel = $('baselineSel');
  const temp = state.tempBaseline ? `<option value="__temp">${esc(state.tempBaseline.name)} (not saved)</option>` : '';
  sel.innerHTML = temp + (state.baselines.length ? state.baselines.map((b) => `<option value="${b.id}">${esc(b.name)}${b.id === state.activeBaseline ? ' (live)' : ''} — ${new Date(b.createdAt).toLocaleDateString()}</option>`).join('')
    : (temp ? '' : '<option value="">(no baselines yet)</option>'));
  sel.value = state.baselineId || '';
  await loadBaseline();
}

async function loadBaseline() {
  state.baseline = state.baselineId === '__temp' ? state.tempBaseline : state.baselineId ? await Store.getBaseline(state.baselineId) : null;
  state.baseStats = state.baseline ? P.baselineStats(state.baseline) : null;
}

/* ---------------- sessions sidebar ---------------- */

function renderSessions() {
  const el = $('sessionList');
  if (!state.index.length) {
    el.innerHTML = '<div class="empty">No sessions yet.<br>Use the toolbar popup to start recording a tab.</div>';
    return;
  }
  const recId = state.recState && state.recState.recording ? state.recState.sessionId : null;
  el.innerHTML = state.index.map((s) => {
    const on = state.selected.has(s.id);
    const dur = s.endedAt ? Math.round((s.endedAt - s.startedAt) / 60000) + ' min' : '';
    return `<div class="sess-item ${on ? 'checked' : ''}" data-id="${s.id}">
      <input type="checkbox" ${on ? 'checked' : ''} tabindex="-1">
      <div><div class="nm">${s.id === recId ? '<span class="rec-dot">● </span>' : ''}${s.rerun ? '<span title="Rerun of a saved flow">↻ </span>' : ''}${esc(s.name)}</div>
      <div class="meta">${esc(fmtTime(s.startedAt))} · ${s.txCount} tx ${dur ? '· ' + dur : ''}</div></div></div>`;
  }).join('');
  el.querySelectorAll('.sess-item').forEach((it) => {
    it.onclick = async () => {
      const id = it.dataset.id;
      if (state.selected.has(id)) state.selected.delete(id); else state.selected.add(id);
      state.expanded.clear();
      renderSessions();
      await loadData();
      renderTab();
    };
  });
}

/* ---------------- tabs ---------------- */

function renderTab() {
  document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('active', b.dataset.tab === state.tab));
  document.querySelectorAll('.panel').forEach((p) => { p.hidden = p.id !== 'p-' + state.tab; });
  const fn = { summary: renderSummary, flow: renderFlow, flows: () => renderFlows(), requests: renderRequests, charts: renderCharts, compare: renderCompare, vitals: renderVitals, settings: renderSettings }[state.tab];
  if (fn) fn();
}

/* ---------------- Transactions (summary) ---------------- */

function renderSummary() {
  const agg = P.aggregateTransactions(state.txs);
  const all = state.txs.map((t) => t.duration);
  const st = P.summarize(all);
  const reqs = state.txs.reduce((s, t) => s + (t.reqCount || 0), 0);
  const errs = state.txs.reduce((s, t) => s + (t.errors || 0), 0);
  const kpi = (l, v, cls) => `<div class="kpi ${cls || ''}"><div class="v">${v}</div><div class="l">${l}</div></div>`;
  $('kpis').innerHTML = kpi('Transactions executed', state.txs.length) + kpi('Distinct transactions', agg.length) +
    kpi('HTTP requests', reqs.toLocaleString()) + kpi('Failed requests', errs, errs ? 'degraded' : '') +
    kpi('Avg transaction', P.fmtMs(st.avg)) + kpi('95th pct (all)', P.fmtMs(st.p95)) + kpi('Page views (vitals)', state.segs.length);

  const f = $('txFilter').value.trim().toLowerCase();
  const rows = agg.map((a, i) => Object.assign({ order: i + 1 }, a)).filter((r) => !f || r.name.toLowerCase().includes(f));
  renderTable('txTable', [
    { key: 'order', label: '#', num: true },
    { key: 'name', label: 'Transaction', cls: 'name', html: (r) => `<span class="sw" style="color:${colorFor(r.name)}">■</span> <span class="tx-name" data-name="${esc(r.name)}" title="${esc(r.name)}">${esc(r.name)}</span>` , csv: (r) => r.name },
    { key: 'type', label: 'Type', html: (r) => typeBadge(r.type) },
    { key: 'count', label: 'Count', num: true },
    { key: 'avg', label: 'Average', num: true, fmt: P.fmtMs },
    { key: 'p95', label: '95th pct', num: true, fmt: P.fmtMs },
    { key: 'p90', label: '90th pct', num: true, fmt: P.fmtMs },
    { key: 'p50', label: 'Median', num: true, fmt: P.fmtMs },
    { key: 'min', label: 'Min', num: true, fmt: P.fmtMs },
    { key: 'max', label: 'Max', num: true, fmt: P.fmtMs },
    { key: 'std', label: 'Std dev', num: true, fmt: P.fmtMs },
    { key: 'avgReqs', label: 'Avg requests', num: true, fmt: (v) => P.fmtNum(v, 1) },
    { key: 'errors', label: 'Errors', num: true, cls: (r) => (r.errors ? 'up' : '') },
    { key: 'avgBytes', label: 'Avg size', num: true, fmt: P.fmtBytes, title: 'From Content-Length headers where present' }
  ], rows, { defaultSort: { key: 'order', dir: 'asc' }, empty: state.sessions.length ? 'No completed transactions in the selected sessions' : 'Select a session on the left' });

  $('txTable').querySelectorAll('.tx-name').forEach((sp) => {
    sp.ondblclick = async () => {
      const from = sp.dataset.name;
      const to = prompt('Rename this transaction in the selected sessions:', from);
      if (!to || to === from) return;
      for (const s of state.sessions) await send({ cmd: 'renameTx', id: s.id, from, to });
      state.colorOf.set(to, colorFor(from));
      await loadData();
      renderTab();
      toast('Renamed');
    };
  });
}

/* ---------------- Session flow ---------------- */

function renderFlow() {
  const multi = state.sessions.length > 1;
  const rows = [];
  for (const s of state.sessions) {
    const list = state.txs.filter((t) => t._sid === s.id).sort((a, b) => a.start - b.start);
    let prevEnd = null;
    list.forEach((t, i) => {
      rows.push({ tx: t, idx: i + 1, session: s.name, offset: t._offset, think: prevEnd == null ? null : Math.max(0, t.start - prevEnd),
        type: t.type, name: t.name, duration: t.duration, reqCount: t.reqCount, errors: t.errors, bytes: t.bytes,
        route: t.routeTo || (t.navPage && t.navPage !== t.page ? t.navPage : ''), sortStart: t.start });
      prevEnd = t.end;
    });
  }
  const cols = [];
  if (multi) cols.push({ key: 'session', label: 'Session', cls: 'name' });
  cols.push(
    { key: 'idx', label: '#', num: true },
    { key: 'offset', label: 'At (m:s)', num: true, fmt: fmtOffset, sortVal: (r) => r.sortStart },
    { key: 'think', label: 'Think time', num: true, fmt: P.fmtMs, title: 'Gap since the previous transaction ended' },
    { key: 'type', label: 'Type', html: (r) => typeBadge(r.type) },
    { key: 'name', label: 'Transaction', cls: 'name', html: (r) => `<span style="color:${colorFor(r.name)}">■</span> ${state.expanded.has(r.tx.id) ? '▾' : '▸'} <span title="${esc(r.name)}">${esc(r.name)}</span>${r.tx.truncated ? ' <span class="badge missing" title="Hit the maximum transaction length">cut</span>' : ''}`, csv: (r) => r.name },
    { key: 'duration', label: 'Response time', num: true, fmt: P.fmtMs },
    { key: 'reqCount', label: 'Requests', num: true },
    { key: 'errors', label: 'Errors', num: true, cls: (r) => (r.errors ? 'up' : '') },
    { key: 'bytes', label: 'Size', num: true, fmt: P.fmtBytes },
    { key: 'route', label: 'Navigated to', cls: 'name' }
  );
  const ncols = cols.length;
  const width = chartWidth($('flowTable')) - 20;
  renderTable('flowTable', cols, rows, {
    defaultSort: { key: 'offset', dir: 'asc' },
    empty: 'No transactions',
    rowAttrs: (r) => `class="clickable" data-id="${r.tx.id}"`,
    after: (r) => {
      if (!state.expanded.has(r.tx.id)) return '';
      const t = r.tx;
      const svg = CH.waterfall({ width, start: t.start, end: t.end, requests: t.requests,
        markers: [{ t: t.dclTime, label: 'DOMContentLoaded', color: '#1a73e8' }, { t: t.loadTime, label: 'Load event', color: '#d93025' }] });
      const info = `<div class="muted small">Started ${esc(new Date(t.start).toLocaleTimeString())} on ${esc(t.pageUrl || '')}${t.label ? ' · action: ' + esc(t.label) : ''}${t.transition ? ' · ' + esc(t.transition) : ''}${t.navError ? ' · navigation error: ' + esc(t.navError) : ''}. Grey bars are long requests excluded from the response time.</div>`;
      return `<tr class="detail"><td colspan="${ncols}">${info}${svg}</td></tr>`;
    }
  });
  $('flowTable').querySelectorAll('tr.clickable').forEach((tr) => {
    tr.onclick = () => { const id = tr.dataset.id; if (state.expanded.has(id)) state.expanded.delete(id); else state.expanded.add(id); renderFlow(); };
  });
}

/* ---------------- Requests ---------------- */

const statusText = (st) => Object.entries(st).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}×${v}`).join(', ');
const reqCols = () => [
  { key: 'method', label: 'Method' },
  { key: 'url', label: 'Request (normalised)', cls: 'wrapname', html: (r) => `<span title="${esc(r.sample)}">${esc(r.url)}</span>` },
  { key: 'type', label: 'Type' },
  { key: 'count', label: 'Count', num: true },
  { key: 'avg', label: 'Average', num: true, fmt: P.fmtMs },
  { key: 'p95', label: '95th pct', num: true, fmt: P.fmtMs },
  { key: 'min', label: 'Min', num: true, fmt: P.fmtMs },
  { key: 'max', label: 'Max', num: true, fmt: P.fmtMs },
  { key: 'statuses', label: 'Status', html: (r) => esc(statusText(r.statuses)), csv: (r) => statusText(r.statuses), sortVal: (r) => r.errors },
  { key: 'cached', label: 'From cache', num: true },
  { key: 'errors', label: 'Errors', num: true, cls: (r) => (r.errors ? 'up' : '') },
  { key: 'avgSize', label: 'Avg size', num: true, fmt: P.fmtBytes },
  { key: 'txCount', label: 'In # tx types', num: true }
];

function renderRequests() {
  const sel = $('reqTx');
  const names = P.aggregateTransactions(state.txs).map((a) => a.name);
  const cur = sel.value;
  sel.innerHTML = '<option value="">All transactions</option>' + names.map((n) => `<option>${esc(n)}</option>`).join('');
  sel.value = names.includes(cur) ? cur : '';
  const opts = { txName: sel.value || null, keepQueryValues: $('reqQueryVals').checked };
  const f = $('reqFilter').value.trim().toLowerCase();
  const rows = P.aggregateRequests(state.txs, opts).filter((r) => !f || r.key.toLowerCase().includes(f) || r.sample.toLowerCase().includes(f));
  renderTable('reqTable', reqCols(), rows, { defaultSort: { key: 'p95', dir: 'desc' }, limit: 500, empty: 'No requests' });
  const orphanRows = P.aggregateRequests([{ name: '(none)', requests: state.orphans }], { keepQueryValues: opts.keepQueryValues })
    .filter((r) => !f || r.key.toLowerCase().includes(f));
  renderTable('orphanTable', reqCols(), orphanRows, { defaultSort: { key: 'count', dir: 'desc' }, limit: 200, empty: 'None' });
}

/* ---------------- Charts ---------------- */

function renderCharts() {
  const agg = P.aggregateTransactions(state.txs);
  if (!state.chartSel) {
    const pick = agg.length <= 12 ? agg : agg.slice().sort((a, b) => b.p95 - a.p95).slice(0, 12);
    state.chartSel = new Set(pick.map((a) => a.name));
  }
  const f = $('pickFilter').value.trim().toLowerCase();
  $('pickList').innerHTML = agg.filter((a) => !f || a.name.toLowerCase().includes(f)).map((a) =>
    `<label title="${esc(a.name)}"><input type="checkbox" data-n="${esc(a.name)}" ${state.chartSel.has(a.name) ? 'checked' : ''}>` +
    `<span class="sw" style="background:${colorFor(a.name)}"></span><span class="t">${esc(a.name)}</span><span class="muted small">${a.count}</span></label>`).join('') ||
    '<div class="empty">No transactions</div>';
  $('pickList').querySelectorAll('input').forEach((cb) => {
    cb.onchange = () => { if (cb.checked) state.chartSel.add(cb.dataset.n); else state.chartSel.delete(cb.dataset.n); drawCharts(); };
  });
  drawCharts();
}

function drawCharts() {
  const agg = P.aggregateTransactions(state.txs).filter((a) => state.chartSel.has(a.name));
  const byTime = $('xMode').value === 'time';
  const series = agg.map((a) => {
    const list = state.txs.filter((t) => t.name === a.name).sort((x, y) => x.start - y.start);
    return {
      name: a.name, color: colorFor(a.name),
      points: list.map((t, i) => ({ x: byTime ? t._offset / 60000 : i + 1, y: t.duration,
        tip: `#${i + 1}: ${P.fmtMs(t.duration)} · ${t.reqCount} requests\n${t._session} · ${new Date(t.start).toLocaleTimeString()}` }))
    };
  });
  const le = $('lineChart');
  le.innerHTML = CH.line({ width: chartWidth(le), height: 360, series, fmt: (v) => P.fmtMs(v).replace(' ms', ''), yLabel: 'Response time (ms)',
    xLabel: byTime ? 'Minutes since session start' : 'Execution #', xFmt: byTime ? (v) => v.toFixed(1) : (v) => String(Math.round(v)), integerX: !byTime, empty: 'Tick transactions on the left' });
  const be = $('barChart');
  be.innerHTML = CH.hbar({ width: chartWidth(be), categories: agg.map((a) => a.name),
    series: [{ name: 'Average', color: '#4e79a7', values: agg.map((a) => a.avg) }, { name: '95th percentile', color: '#f28e2b', values: agg.map((a) => a.p95) }],
    fmt: (v) => P.fmtMs(v), empty: 'Tick transactions on the left' });
}

/* ---------------- Compare ---------------- */

function cmpOpts() {
  return { metric: $('cmpMetric').value, thresholdPct: Number($('thrPct').value) || 0, thresholdMs: Number($('thrMs').value) || 0 };
}

function computeCompare() {
  if (!state.baseStats) return null;
  const o = cmpOpts();
  const tx = P.compare(state.baseStats.transactions, P.aggregateTransactions(state.txs), o);
  const req = P.compare(state.baseStats.requests, P.aggregateRequests(state.txs), Object.assign({ key: 'key' }, o));
  return { o, tx, req };
}

function renderCompare() {
  const info = $('cmpInfo');
  if (!state.baseline) {
    info.innerHTML = 'No baseline yet. Tick the session(s) that represent the reference run on the left, type a name and click <b>Save as baseline</b>.';
    ['cmpTiles', 'cmpStack', 'cmpTable', 'cmpBar', 'cmpDiv', 'cmpReqTable', 'cmpVitTable'].forEach((id) => { $(id).innerHTML = ''; });
    return;
  }
  const b = state.baseline;
  info.textContent = `Baseline "${b.name}" (${new Date(b.createdAt).toLocaleString()}, from ${b.sourceSessions.map((s) => s.name).join(', ')}) vs current = the ${state.sessions.length} session(s) ticked on the left. ` +
    `A transaction counts as improved/degraded when the ${cmpOpts().metric} changes by at least ${cmpOpts().thresholdPct}% and ${cmpOpts().thresholdMs} ms.`;
  const r = computeCompare();
  const c = r.tx.counts;
  const common = r.tx.rows.filter((x) => x.base && x.cur);
  const sb = common.reduce((s, x) => s + x.bv, 0), sc = common.reduce((s, x) => s + x.cv, 0);
  const kpi = (l, v, cls, t) => `<div class="kpi ${cls || ''}" title="${esc(t || '')}"><div class="v">${v}</div><div class="l">${l}</div></div>`;
  $('cmpTiles').innerHTML = kpi('Improved', c.improved, 'improved') + kpi('Degraded', c.degraded, 'degraded') + kpi('Unchanged', c.unchanged) +
    kpi('New', c.new, 'new', 'Only in the current sessions') + kpi('Missing', c.missing, 'missing', 'Only in the baseline') +
    kpi(`Total ${r.o.metric} change`, sb ? P.fmtPct(((sc - sb) / sb) * 100) : '–', sc > sb ? 'degraded' : 'improved', `Sum of ${r.o.metric} over transactions in both: ${P.fmtMs(sb)} → ${P.fmtMs(sc)}`);
  const se = $('cmpStack');
  se.innerHTML = CH.stack({ width: chartWidth(se), parts: ['improved', 'degraded', 'unchanged', 'new', 'missing'].map((k) => ({ label: k, value: c[k], color: CH.STATUS[k] })) });

  if (state.cmpSelFor !== state.baselineId || !state.cmpSel) {
    state.cmpSelFor = state.baselineId;
    state.cmpSel = new Set(common.slice().sort((x, y) => Math.abs(y.pct || 0) - Math.abs(x.pct || 0)).slice(0, 20).map((x) => x.name));
  }
  const sf = $('cmpStatusFilter').value;
  const rows = r.tx.rows.filter((x) => !sf || x.status === sf).map((x) => Object.assign(x, {
    bCount: x.base && x.base.count, bAvg: x.base && x.base.avg, bP95: x.base && x.base.p95,
    cCount: x.cur && x.cur.count, cAvg: x.cur && x.cur.avg, cP95: x.cur && x.cur.p95 }));
  renderTable('cmpTable', [
    { key: 'sel', label: '✓', noCsv: true, html: (x) => (x.base && x.cur ? `<input type="checkbox" data-n="${esc(x.name)}" ${state.cmpSel.has(x.name) ? 'checked' : ''}>` : ''), sortVal: (x) => (state.cmpSel.has(x.name) ? 1 : 0) },
    { key: 'name', label: 'Transaction', cls: 'name', html: (x) => `<span title="${esc(x.name)}">${esc(x.name)}</span>`, csv: (x) => x.name },
    { key: 'type', label: 'Type', html: (x) => typeBadge(x.type) },
    { key: 'bCount', label: 'Base #', num: true },
    { key: 'bAvg', label: 'Base avg', num: true, fmt: P.fmtMs },
    { key: 'bP95', label: 'Base 95th', num: true, fmt: P.fmtMs },
    { key: 'cCount', label: 'Current #', num: true },
    { key: 'cAvg', label: 'Current avg', num: true, fmt: P.fmtMs },
    { key: 'cP95', label: 'Current 95th', num: true, fmt: P.fmtMs },
    { key: 'delta', label: `Δ ${r.o.metric}`, num: true, fmt: (v) => (v == null ? '–' : (v > 0 ? '+' : '') + P.fmtMs(v)), cls: (x) => (x.status === 'degraded' ? 'up' : x.status === 'improved' ? 'down' : '') },
    { key: 'pct', label: 'Δ %', num: true, fmt: P.fmtPct, cls: (x) => (x.status === 'degraded' ? 'up' : x.status === 'improved' ? 'down' : '') },
    { key: 'status', label: 'Status', html: (x) => statusBadge(x.status), sortVal: (x) => ({ degraded: 0, improved: 1, unchanged: 2, new: 3, missing: 4 }[x.status]) }
  ], rows, { defaultSort: { key: 'pct', dir: 'desc' }, empty: 'Nothing to compare' });
  $('cmpTable').querySelectorAll('input[data-n]').forEach((cb) => {
    cb.onchange = () => { if (cb.checked) state.cmpSel.add(cb.dataset.n); else state.cmpSel.delete(cb.dataset.n); drawCompareCharts(r); };
  });
  drawCompareCharts(r);

  const reqRows = r.req.rows.filter((x) => x.base && x.cur).sort((x, y) => Math.abs(y.delta) - Math.abs(x.delta)).slice(0, 60)
    .map((x) => Object.assign(x, { bc: x.base.count, cc: x.cur.count }));
  renderTable('cmpReqTable', [
    { key: 'name', label: 'Request', cls: 'wrapname' },
    { key: 'bc', label: 'Base #', num: true },
    { key: 'bv', label: `Base ${r.o.metric}`, num: true, fmt: P.fmtMs },
    { key: 'cc', label: 'Current #', num: true },
    { key: 'cv', label: `Current ${r.o.metric}`, num: true, fmt: P.fmtMs },
    { key: 'delta', label: 'Δ', num: true, fmt: (v) => (v > 0 ? '+' : '') + P.fmtMs(v), cls: (x) => (x.status === 'degraded' ? 'up' : x.status === 'improved' ? 'down' : '') },
    { key: 'pct', label: 'Δ %', num: true, fmt: P.fmtPct },
    { key: 'status', label: 'Status', html: (x) => statusBadge(x.status) }
  ], reqRows, { defaultSort: { key: 'delta', dir: 'desc' }, empty: 'No requests in common' });

  renderVitalsCompare();
}

function drawCompareCharts(r) {
  const rows = r.tx.rows.filter((x) => x.base && x.cur && state.cmpSel.has(x.name)).sort((x, y) => (y.pct || 0) - (x.pct || 0));
  const be = $('cmpBar');
  be.innerHTML = CH.hbar({ width: chartWidth(be), categories: rows.map((x) => x.name), fmt: (v) => P.fmtMs(v),
    series: [{ name: `Baseline ${r.o.metric}`, color: '#9aa0a6', values: rows.map((x) => x.bv) },
      { name: `Current ${r.o.metric} (green improved / red degraded / blue unchanged)`, legendColor: '#4e79a7', color: (i) => (rows[i].status === 'degraded' ? CH.STATUS.degraded : rows[i].status === 'improved' ? CH.STATUS.improved : '#4e79a7'), values: rows.map((x) => x.cv) }],
    empty: 'Tick transactions in the table above' });
  const de = $('cmpDiv');
  de.innerHTML = CH.diverging({ width: chartWidth(de), items: rows.map((x) => ({ label: x.name, value: x.pct, color: CH.STATUS[x.status] || '#80868b',
    tip: `${P.fmtMs(x.bv)} → ${P.fmtMs(x.cv)} (${P.fmtPct(x.pct)})` })), empty: 'Tick transactions in the table above' });
}

const VIT_COLS = ['ttfb', 'fcp', 'lcp', 'cls', 'inp', 'tbt'];

function vitalsDeltaCell(k, b, c) {
  if (b == null && c == null) return '–';
  if (b == null || c == null) return `${P.fmtVital(k, b)} → ${P.fmtVital(k, c)}`;
  const pct = b ? ((c - b) / b) * 100 : 0;
  const minAbs = k === 'cls' ? 0.02 : Number($('thrMs').value) || 0;
  const thr = Number($('thrPct').value) || 0;
  const cls = pct >= thr && c - b >= minAbs ? 'up' : pct <= -thr && b - c >= minAbs ? 'down' : 'muted';
  return `${P.fmtVital(k, b)} → <b>${P.fmtVital(k, c)}</b> <span class="${cls}">${b ? P.fmtPct(pct) : ''}</span>`;
}

function renderVitalsCompare() {
  const cur = P.aggregateVitals(state.segs);
  const base = state.baseStats.vitals;
  const key = (v) => v.page + '|' + v.kind;
  const bm = new Map(base.map((v) => [key(v), v]));
  const cm = new Map(cur.map((v) => [key(v), v]));
  const keys = Array.from(new Set(base.map(key).concat(cur.map(key))));
  const rows = keys.map((k) => { const b = bm.get(k), c = cm.get(k); const x = b || c; return { page: x.page, kind: x.kind, b, c, bv: b ? b.visits : 0, cv: c ? c.visits : 0 }; });
  const cols = [
    { key: 'page', label: 'Page', cls: 'name' },
    { key: 'kind', label: 'Kind', fmt: (v) => (v === 'soft' ? 'route change' : 'page load') },
    { key: 'bv', label: 'Base views', num: true },
    { key: 'cv', label: 'Current views', num: true }
  ];
  VIT_COLS.forEach((k) => cols.push({ key: k, label: P.VITALS[k].label, num: true,
    html: (x) => vitalsDeltaCell(k, x.b && x.b[k + '_p75'], x.c && x.c[k + '_p75']),
    csv: (x) => `${x.b && x.b[k + '_p75'] != null ? Math.round(x.b[k + '_p75'] * 1000) / 1000 : ''} -> ${x.c && x.c[k + '_p75'] != null ? Math.round(x.c[k + '_p75'] * 1000) / 1000 : ''}`,
    sortVal: (x) => (x.c && x.c[k + '_p75']),
    cls: (x) => P.rate(k, x.c && x.c[k + '_p75']) || '' }));
  renderTable('cmpVitTable', cols, rows, { defaultSort: { key: 'cv', dir: 'desc' }, empty: 'No Web Vitals in baseline or current sessions' });
}

/* ---------------- Web Vitals ---------------- */

function renderVitals() {
  const segs = state.segs.filter((s) => $('vitSoft').checked || s.kind === 'hard');
  const agg = P.aggregateVitals(segs);
  const vcol = (k) => ({ key: k + '_p75', label: P.VITALS[k].label + ' p75', num: true, title: P.VITALS[k].desc,
    fmt: (v) => P.fmtVital(k, v), cls: (r) => P.rate(k, r[k + '_p75']) || '' });
  renderTable('vitTable', [
    { key: 'page', label: 'Page', cls: 'name', html: (r) => `<span title="${esc(r.sample)}">${esc(r.page)}</span>`, csv: (r) => r.page },
    { key: 'kind', label: 'Kind', fmt: (v) => (v === 'soft' ? 'route change' : 'page load') },
    { key: 'visits', label: 'Views', num: true },
    vcol('ttfb'), vcol('fcp'), vcol('lcp'), vcol('cls'), vcol('inp'), vcol('tbt'),
    { key: 'dcl_avg', label: 'DOMContentLoaded', num: true, fmt: P.fmtMs },
    { key: 'load_avg', label: 'Load event', num: true, fmt: P.fmtMs },
    { key: 'resources_avg', label: 'Resources', num: true, fmt: (v) => P.fmtNum(v, 0) },
    { key: 'transferSize_avg', label: 'Doc transfer', num: true, fmt: P.fmtBytes }
  ], agg, { defaultSort: { key: 'visits', dir: 'desc' }, empty: 'No page views captured. Web Vitals are collected for pages loaded while recording.' });

  const hard = agg.filter((a) => a.kind === 'hard');
  const ce = $('vitChart');
  ce.innerHTML = CH.hbar({ width: chartWidth(ce), categories: hard.map((a) => a.page), fmt: (v) => P.fmtMs(v),
    series: [{ name: 'TTFB', color: '#76b7b2', values: hard.map((a) => a.ttfb_p75) }, { name: 'FCP', color: '#4e79a7', values: hard.map((a) => a.fcp_p75) },
      { name: 'LCP', color: '#f28e2b', values: hard.map((a) => a.lcp_p75) }, { name: 'Load event', color: '#b07aa1', values: hard.map((a) => a.load_avg) }],
    empty: 'No full page loads captured' });

  const visits = segs.slice().sort((a, b) => a.startEpoch - b.startEpoch).map((s) => Object.assign({}, s, { page: P.pagePath(s.url), dcl: s.nav && s.nav.dcl, load: s.nav && s.nav.load, navType: s.nav && s.nav.type }));
  const rc = (k) => ({ key: k, label: P.VITALS[k].label, num: true, fmt: (v) => P.fmtVital(k, v), cls: (r) => P.rate(k, r[k]) || '' });
  renderTable('vitVisits', [
    { key: 'startEpoch', label: 'Time', fmt: (v) => new Date(v).toLocaleTimeString() },
    { key: '_session', label: 'Session', cls: 'name' },
    { key: 'page', label: 'Page', cls: 'name', html: (r) => `<span title="${esc(r.url)}">${esc(r.title || r.page)}</span>`, csv: (r) => r.url },
    { key: 'kind', label: 'Kind', fmt: (v) => (v === 'soft' ? 'route' : 'load') },
    rc('ttfb'), rc('fcp'), rc('lcp'),
    { key: 'lcpElement', label: 'LCP element', cls: 'name' },
    rc('cls'), rc('inp'), rc('tbt'),
    { key: 'longTasks', label: 'Long tasks', num: true },
    { key: 'interactions', label: 'Interactions', num: true },
    { key: 'dcl', label: 'DCL', num: true, fmt: P.fmtMs },
    { key: 'load', label: 'Load', num: true, fmt: P.fmtMs },
    { key: 'navType', label: 'Nav type' }
  ], visits, { defaultSort: { key: 'startEpoch', dir: 'asc' }, limit: 500, empty: 'No page views' });
}

/* ---------------- Settings ---------------- */

async function renderSettings() {
  const s = state.settings = await Store.getSettings();
  const f = $('settingsForm');
  for (const el of f.elements) {
    if (!el.name) continue;
    const v = s[el.name];
    if (el.type === 'checkbox') el.checked = !!v;
    else if (el.name === 'ignorePatterns') el.value = (v || []).join('\n');
    else if (el.name === 'ignoreTypes') el.value = (v || []).join(', ');
    else el.value = v == null ? '' : v;
  }
  chrome.storage.local.getBytesInUse(null).then((b) => { $('storageUsed').textContent = P.fmtBytes(b); });
}

$('settingsForm').onsubmit = async (e) => {
  e.preventDefault();
  const f = e.target;
  const s = Object.assign({}, state.settings);
  for (const el of f.elements) {
    if (!el.name) continue;
    if (el.type === 'checkbox') s[el.name] = el.checked;
    else if (el.type === 'number') s[el.name] = Number(el.value);
    else if (el.name === 'ignorePatterns') s[el.name] = el.value.split('\n').map((x) => x.trim()).filter(Boolean);
    else if (el.name === 'ignoreTypes') s[el.name] = el.value.split(',').map((x) => x.trim()).filter(Boolean);
    else s[el.name] = el.value;
  }
  const bad = s.ignorePatterns.filter((p) => { try { new RegExp(p); return false; } catch (x) { return true; } });
  if (bad.length) { $('settingsMsg').textContent = 'Invalid pattern: ' + bad.join(', '); return; }
  await Store.saveSettings(s);
  state.settings = s;
  $('settingsMsg').textContent = 'Saved.';
  setTimeout(() => { $('settingsMsg').textContent = ''; }, 2000);
};
$('resetSettings').onclick = async () => { await Store.saveSettings(Object.assign({}, Store.DEFAULT_SETTINGS)); renderSettings(); toast('Defaults restored'); };

/* ---------------- actions ---------------- */

$('tabs').onclick = (e) => { const b = e.target.closest('button[data-tab]'); if (!b) return; state.tab = b.dataset.tab; renderTab(); };
document.querySelectorAll('[data-csv]').forEach((b) => { b.onclick = () => tableCsv(b.dataset.csv); });
$('txFilter').oninput = () => renderSummary();
$('reqFilter').oninput = () => renderRequests();
$('reqTx').onchange = () => renderRequests();
$('reqQueryVals').onchange = () => renderRequests();
$('pickFilter').oninput = () => renderCharts();
$('pickAll').onclick = () => { P.aggregateTransactions(state.txs).forEach((a) => state.chartSel.add(a.name)); renderCharts(); };
$('pickNone').onclick = () => { state.chartSel.clear(); renderCharts(); };
$('xMode').onchange = () => drawCharts();
$('vitSoft').onchange = () => renderVitals();
['cmpMetric', 'thrPct', 'thrMs', 'cmpStatusFilter'].forEach((id) => { $(id).onchange = () => renderCompare(); });
$('baselineSel').onchange = async () => { state.baselineId = $('baselineSel').value || null; await loadBaseline(); renderCompare(); };

$('saveBaselineBtn').onclick = async () => {
  if (!state.sessions.length) return toast('Tick at least one session first');
  if (!state.txs.length) return toast('The selected sessions have no transactions');
  const name = $('baselineName').value.trim() || `Baseline ${new Date().toLocaleString()}`;
  const b = P.buildBaseline(name, state.sessions);
  await Store.saveBaseline(b);
  if (!(await Store.get('activeBaseline', null))) await Store.set('activeBaseline', b.id);
  $('baselineName').value = '';
  state.baselineId = b.id;
  await loadBaselines();
  toast(`Baseline "${name}" saved (${b.transactions.length} transactions)`);
};

const notTemp = () => { if (state.baselineId === '__temp') { toast('This is a flow reference run, not a saved baseline. Use "Save as baseline" on the run.'); return false; } return true; };
$('activeBaselineBtn').onclick = async () => { if (!state.baselineId || !notTemp()) return; await Store.set('activeBaseline', state.baselineId); await loadBaselines(); toast('Popup now compares live with this baseline'); };
$('renameBaselineBtn').onclick = async () => {
  if (!state.baseline || !notTemp()) return;
  const n = prompt('Baseline name', state.baseline.name);
  if (!n) return;
  state.baseline.name = n;
  await Store.saveBaseline(state.baseline);
  await loadBaselines();
  renderCompare();
};
$('deleteBaselineBtn').onclick = async () => {
  if (!state.baseline || !notTemp() || !confirm(`Delete baseline "${state.baseline.name}"? This cannot be undone.`)) return;
  await Store.deleteBaseline(state.baseline.id);
  state.baselineId = null;
  await loadBaselines();
  renderCompare();
};
$('exportBaselineBtn').onclick = () => {
  if (!state.baseline) return;
  download(`baseline-${state.baseline.name.replace(/[^\w.-]+/g, '_')}.json`, JSON.stringify({ format: 'txperf', version: 1, baselines: [state.baseline] }, null, 1));
};

$('renameSessBtn').onclick = async () => {
  if (state.sessions.length !== 1) return toast('Tick exactly one session to rename');
  const s = state.sessions[0];
  const n = prompt('Session name', s.name);
  if (!n) return;
  await send({ cmd: 'renameSession', id: s.id, name: n });
  await loadIndex(); await loadData(); renderTab();
};
$('deleteSessBtn').onclick = async () => {
  if (!state.sessions.length) return;
  if (!confirm(`Delete ${state.sessions.length} session(s)? This cannot be undone. Baselines already saved are kept.`)) return;
  for (const s of state.sessions) {
    const r = await send({ cmd: 'deleteSession', id: s.id });
    if (r && !r.ok) toast(r.error);
  }
  state.selected.clear();
  await loadIndex(); await loadData(); renderTab();
};

$('exportBtn').onclick = () => {
  if (!state.sessions.length) return toast('Tick at least one session');
  const strip = (s) => JSON.parse(JSON.stringify(s, (k, v) => (k[0] === '_' ? undefined : v)));
  download(`txperf-sessions-${fileStamp()}.json`, JSON.stringify({ format: 'txperf', version: 1, exportedAt: Date.now(), sessions: state.sessions.map(strip) }, null, 1));
};

$('importFile').onchange = async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    let ns = 0, nb = 0;
    const sessions = data.sessions || (data.transactions && data.startedAt ? [data] : []);
    const baselines = data.baselines || (data.transactions && data.createdAt && !data.startedAt ? [data] : []);
    for (const s of sessions) { if (s.id && Array.isArray(s.transactions)) { await Store.saveSession(s); ns++; } }
    for (const b of baselines) { if (b.id && Array.isArray(b.transactions)) { await Store.saveBaseline(b); nb++; } }
    let nf = 0;
    for (const f of data.flows || []) { if (f.id && Array.isArray(f.steps)) { f.runs = f.runs || []; await Store.saveFlow(f); nf++; } }
    await loadIndex(); await loadBaselines(); await loadData(); renderTab();
    toast(`Imported ${ns} session(s), ${nb} baseline(s), ${nf} flow(s)`);
  } catch (err) { toast('Import failed: ' + err.message); }
};

$('reportBtn').onclick = () => {
  if (!state.sessions.length) return toast('Tick at least one session');
  const html = TxReport.build({
    sessions: state.sessions, txs: state.txs, segs: state.segs,
    baseline: state.baseline, baseStats: state.baseStats, compare: computeCompare(), colorFor
  });
  download(`txperf-report-${fileStamp()}.html`, html, 'text/html');
};

/* ---------------- live updates ---------------- */

let liveTimer = null;
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local') return;
  const keys = Object.keys(ch);
  const idx = keys.some((k) => k === 'sessionsIndex' || k === 'recState');
  const data = keys.some((k) => k.startsWith('session:') && state.selected.has(k.slice(8)));
  const base = keys.some((k) => k === 'baselinesIndex' || k === 'activeBaseline');
  const flows = keys.some((k) => k === 'flowsIndex' || k === 'replayState' || k.startsWith('flow:'));
  if (!idx && !data && !base && !flows) return;
  clearTimeout(liveTimer);
  liveTimer = setTimeout(async () => {
    if (idx) await loadIndex();
    if (base) await loadBaselines();
    if (data) await loadData();
    if (state.tab === 'flows' || (state.tab !== 'settings' && (idx || data || base))) renderTab();
  }, 1200);
});

let resizeTimer = null;
addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(() => { if (['charts', 'compare', 'vitals', 'flow'].includes(state.tab)) renderTab(); }, 250); });

/* ---------------- init ---------------- */

(async () => {
  state.settings = await Store.getSettings();
  $('cmpMetric').value = state.settings.compareMetric;
  $('thrPct').value = state.settings.thresholdPct;
  $('thrMs').value = state.settings.thresholdMs;
  const hash = location.hash.slice(1);
  if (hash && document.querySelector(`#tabs button[data-tab="${hash}"]`)) state.tab = hash;
  await loadIndex();
  await loadBaselines();
  await loadData();
  renderTab();
})();
