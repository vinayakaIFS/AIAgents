/* Transaction Perf Recorder - content script.
 * 1. Reports user actions (click, Enter, select change, form submit) so the worker can open a transaction,
 *    together with element locators so the flow can be rerun later.
 * 2. Optionally records values typed into text fields (never password fields) so reruns can replay them.
 * 3. Performs steps when the worker reruns a saved flow (locate element, then click / type / select).
 * 4. Collects Web Vitals for the top frame: TTFB, FCP, LCP, CLS, INP, TBT plus navigation timings.
 *    A full page load is a "hard" segment; each SPA route change starts a "soft" segment
 *    (CLS / INP / TBT measured from the route change; LCP / FCP / TTFB only exist for hard loads).
 * Nothing is sent unless a recording is active. */
(() => {
  if (window.__txPerfLoaded) return;
  window.__txPerfLoaded = true;

  const isTop = window === window.top;
  let recording = false;   // a recording (or rerun) is active: send Web Vitals
  let capture = false;     // a user recording is active: report actions / typed values
  let recordInputs = true;

  const send = (m) => {
    try { chrome.runtime.sendMessage(m).catch(() => {}); } catch (e) { /* extension reloaded */ }
  };

  try {
    chrome.storage.local.get(['recState', 'settings']).then((o) => {
      recording = !!(o.recState && o.recState.recording);
      capture = recording && !o.recState.replay;
      recordInputs = !(o.settings && o.settings.recordInputValues === false);
      if (recording && isTop) flush(false);
    });
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== 'local') return;
      if (ch.settings) recordInputs = !(ch.settings.newValue && ch.settings.newValue.recordInputValues === false);
      if (ch.recState) {
        const nv = ch.recState.newValue;
        const was = recording;
        recording = !!(nv && nv.recording);
        capture = recording && !nv.replay;
        if (recording && !was && isTop) flush(false);
      }
    });
  } catch (e) { return; }

  /* ---------------- user actions ---------------- */

  const INTERACTIVE = 'button,a,input,select,textarea,summary,label,[role=button],[role=link],[role=menuitem],' +
    '[role=menuitemcheckbox],[role=menuitemradio],[role=tab],[role=option],[role=checkbox],[role=radio],' +
    '[role=switch],[role=treeitem],[role=gridcell],[role=row],[onclick],[tabindex]';
  const TEXT_INPUTS = ['', 'text', 'search', 'email', 'number', 'tel', 'url', 'date', 'datetime-local', 'time', 'month', 'week'];

  const clean = (s) => (s || '').replace(/\s+/g, ' ').trim().slice(0, 60);
  const q = (s) => String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  const dynamicId = (id) => /\d{3,}|[0-9a-f]{8}-[0-9a-f]{4}|^(ember|ext-|react-|mui-|:r)/i.test(id);

  function targetOf(target) {
    const el = target && target.nodeType === 1 ? target : target && target.parentElement;
    if (!el) return null;
    return (el.closest && el.closest(INTERACTIVE)) || el;
  }

  function textOf(t) {
    const tag = t.tagName.toLowerCase();
    const type = (t.getAttribute('type') || '').toLowerCase();
    let txt = clean(t.getAttribute('aria-label')) || clean(t.getAttribute('title'));
    if (!txt && tag === 'input' && ['button', 'submit', 'reset'].includes(type)) txt = clean(t.value);
    if (!txt && !['input', 'textarea', 'select'].includes(tag)) txt = clean((t.innerText || t.textContent || '').split('\n')[0]);
    if (!txt && t.labels && t.labels[0]) txt = clean(t.labels[0].innerText);
    if (!txt) txt = clean(t.getAttribute('placeholder')) || clean(t.getAttribute('name')) || clean(t.getAttribute('data-testid')) || clean(t.id);
    if (!txt) {
      const alt = t.querySelector && t.querySelector('img[alt],[aria-label]');
      if (alt) txt = clean(alt.getAttribute('alt') || alt.getAttribute('aria-label'));
    }
    return txt;
  }

  function roleOf(t) {
    const tag = t.tagName.toLowerCase();
    const type = (t.getAttribute('type') || '').toLowerCase();
    return t.getAttribute('role') || (tag === 'a' ? 'link' : tag === 'input' ? (type || 'input') : tag);
  }

  function describe(target) {
    const t = targetOf(target);
    if (!t) return 'element';
    const txt = textOf(t) || clean(String(t.className || '').split(' ')[0]) || t.tagName.toLowerCase();
    return `${roleOf(t)} "${txt}"`;
  }

  function cssPath(el) {
    const parts = [];
    while (el && el.nodeType === 1 && el !== document.documentElement && parts.length < 14) {
      if (el.id && !dynamicId(el.id)) { parts.unshift('#' + CSS.escape(el.id)); break; }
      let p = el.tagName.toLowerCase();
      const par = el.parentElement;
      if (par) {
        const sib = Array.from(par.children).filter((c) => c.tagName === el.tagName);
        if (sib.length > 1) p += `:nth-of-type(${sib.indexOf(el) + 1})`;
      }
      parts.unshift(p);
      el = par;
    }
    return parts.join(' > ');
  }

  // Locator candidates, most stable first. The last one (CSS path) is the fallback.
  function locatorOf(target) {
    const t = targetOf(target);
    if (!t) return null;
    const tag = t.tagName.toLowerCase();
    const sel = [];
    for (const a of ['data-testid', 'data-test-id', 'data-test', 'data-automation-id', 'data-cy']) {
      const v = t.getAttribute(a);
      if (v) sel.push(`[${a}="${q(v)}"]`);
    }
    if (t.id && !dynamicId(t.id)) sel.push('#' + CSS.escape(t.id));
    const nm = t.getAttribute('name');
    if (nm) sel.push(`${tag}[name="${q(nm)}"]`);
    const al = t.getAttribute('aria-label');
    if (al) sel.push(`${tag}[aria-label="${q(al)}"]`);
    const ti = t.getAttribute('title');
    if (ti && !al) sel.push(`${tag}[title="${q(ti)}"]`);
    if (tag === 'a' && t.getAttribute('href') && !/^javascript:|^#$/.test(t.getAttribute('href'))) sel.push(`a[href="${q(t.getAttribute('href'))}"]`);
    sel.push(cssPath(t));
    let frame = 'top';
    if (!isTop) frame = location.origin + location.pathname;
    return { selectors: sel, text: textOf(t), tag, role: roleOf(t), frame };
  }

  const epoch = (ev) => performance.timeOrigin + (ev && ev.timeStamp ? ev.timeStamp : performance.now());
  let lastActionAt = 0;
  const typed = new WeakMap(); // element -> value already recorded

  function pageUrlOf() {
    try { return window.top.location.href; } catch (e) { return location.href; }
  }

  function action(kind, label, ev, extra) {
    if (!capture || (ev && !ev.isTrusted)) return;
    const ts = epoch(ev);
    if (ts - lastActionAt < 40) return; // Enter on a button also fires click
    lastActionAt = ts;
    send(Object.assign({ type: 'action', kind, label, ts, pageUrl: pageUrlOf(), sel: locatorOf(ev && ev.target) }, extra || {}));
  }

  const isTextField = (el) => el && ((el.tagName === 'INPUT' && TEXT_INPUTS.includes((el.getAttribute('type') || '').toLowerCase())) || el.tagName === 'TEXTAREA');

  function typedStep(el, ev) {
    if (!capture || !recordInputs || !ev.isTrusted || !isTextField(el)) return;
    if (typed.get(el) === el.value) return;
    typed.set(el, el.value);
    send({ type: 'step', kind: 'input', label: 'Type in ' + describe(el), ts: epoch(ev), pageUrl: pageUrlOf(), sel: locatorOf(el), value: el.value });
  }

  document.addEventListener('click', (ev) => action('click', 'Click ' + describe(ev.target), ev), true);
  document.addEventListener('keydown', (ev) => {
    if (ev.key !== 'Enter' || ev.isComposing) return;
    const el = ev.target;
    if ((el && el.tagName === 'TEXTAREA') || (el && el.isContentEditable)) return;
    typedStep(el, ev); // value must be replayed before the Enter
    action('enter', 'Enter ' + describe(el), ev);
  }, true);
  document.addEventListener('change', (ev) => {
    const el = ev.target;
    if (el && el.tagName === 'SELECT') action('select', 'Select ' + describe(el), ev, { value: el.value });
    else typedStep(el, ev);
  }, true);
  document.addEventListener('submit', (ev) => action('submit', 'Submit form "' + clean((ev.target && (ev.target.id || ev.target.name || ev.target.action)) || '') + '"', ev), true);

  /* ---------------- rerun: perform recorded steps ---------------- */

  const visible = (e) => e && e.getClientRects().length > 0 && !e.disabled && getComputedStyle(e).visibility !== 'hidden';

  function findEl(sel) {
    if (!sel) return null;
    const list = sel.selectors || [];
    for (let i = 0; i < list.length; i++) {
      let found;
      try { found = Array.from(document.querySelectorAll(list[i])).filter(visible); } catch (e) { continue; }
      if (!found.length) continue;
      if (found.length === 1) return found[0];
      if (sel.text) { const m = found.find((e) => textOf(e) === sel.text); if (m) return m; }
      if (i === list.length - 1) return found[0];
    }
    if (sel.text) {
      let cands = [];
      try { cands = Array.from(document.querySelectorAll(sel.tag || INTERACTIVE)); } catch (e) { /* ignore */ }
      const m = cands.filter(visible).find((e) => textOf(e) === sel.text && roleOf(e) === sel.role) ||
        cands.filter(visible).find((e) => textOf(e) === sel.text);
      if (m) return m;
    }
    return null;
  }

  async function locate(sel, timeout) {
    const t0 = performance.now();
    for (;;) {
      const el = findEl(sel);
      if (el) return el;
      if (performance.now() - t0 > timeout) return null;
      await new Promise((r) => setTimeout(r, 200));
    }
  }

  function mouse(el, type) {
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, composed: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
    el.dispatchEvent(type.startsWith('pointer') ? new PointerEvent(type, Object.assign({ pointerId: 1, isPrimary: true, pointerType: 'mouse' }, o)) : new MouseEvent(type, o));
  }

  function setValue(el, value) {
    el.focus();
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function perform(el, step) {
    try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) { /* ignore */ }
    switch (step.kind) {
      case 'input': setValue(el, step.value == null ? '' : step.value); el.blur(); break;
      case 'select': setValue(el, step.value == null ? el.value : step.value); break;
      case 'enter': {
        el.focus();
        const o = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
        const ok = el.dispatchEvent(new KeyboardEvent('keydown', o));
        el.dispatchEvent(new KeyboardEvent('keypress', o));
        el.dispatchEvent(new KeyboardEvent('keyup', o));
        if (ok && el.form && el.tagName === 'INPUT') { try { el.form.requestSubmit(); } catch (e) { /* ignore */ } }
        break;
      }
      case 'submit': { const f = el.closest('form') || el; try { f.requestSubmit(); } catch (e) { f.submit(); } break; }
      default:
        ['pointerover', 'mouseover', 'pointerdown', 'mousedown'].forEach((t) => mouse(el, t));
        if (el.focus) el.focus();
        ['pointerup', 'mouseup'].forEach((t) => mouse(el, t));
        el.click();
    }
  }

  let located = null;
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.cmd === 'txperf-locate') {
      locate(msg.step.sel, msg.timeout || 20000).then((el) => {
        located = el;
        sendResponse({ found: !!el, desc: el ? describe(el) : null });
      });
      return true;
    }
    if (msg && msg.cmd === 'txperf-act') {
      const el = (located && located.isConnected && located) || findEl(msg.step.sel);
      if (!el) { sendResponse({ ok: false, error: 'element disappeared' }); return false; }
      sendResponse({ ok: true });
      setTimeout(() => perform(el, msg.step), 0);
      return false;
    }
    return false;
  });

  if (!isTop) return; // Web Vitals only for the top frame

  /* ---------------- Web Vitals ---------------- */

  const segId = () => Math.random().toString(36).slice(2) + Date.now().toString(36);
  let userInput = false;
  let dirty = true;

  function newSeg(kind) {
    const rel = kind === 'hard' ? 0 : performance.now();
    return {
      id: segId(), kind, url: location.href, title: '', startRel: rel, startEpoch: performance.timeOrigin + rel,
      ttfb: null, fcp: null, lcp: null, lcpElement: null, cls: 0, inp: null, tbt: 0, longTasks: 0, interactions: 0,
      nav: null, resources: null, transferSize: null,
      _int: new Map(), _win: { sum: 0, first: 0, last: 0 }
    };
  }
  let seg = newSeg('hard');

  function nodeName(el) {
    if (!el || !el.tagName) return null;
    let s = el.tagName.toLowerCase();
    if (el.id) s += '#' + el.id;
    else if (el.classList && el.classList.length) s += '.' + Array.from(el.classList).slice(0, 2).join('.');
    return s.slice(0, 80);
  }

  function observe(type, cb, extra) {
    try {
      const po = new PerformanceObserver((list) => { list.getEntries().forEach(cb); dirty = true; });
      po.observe(Object.assign({ type, buffered: true }, extra || {}));
    } catch (e) { /* unsupported entry type */ }
  }

  observe('paint', (e) => { if (e.name === 'first-contentful-paint' && seg.kind === 'hard' && seg.fcp == null) seg.fcp = e.startTime; });

  observe('largest-contentful-paint', (e) => {
    if (seg.kind !== 'hard' || userInput) return;
    seg.lcp = e.startTime;
    seg.lcpElement = nodeName(e.element) || (e.url ? e.url.slice(0, 120) : null);
  });

  observe('layout-shift', (e) => {
    if (e.hadRecentInput || e.startTime < seg.startRel) return;
    const w = seg._win;
    if (w.sum && e.startTime - w.last < 1000 && e.startTime - w.first < 5000) { w.sum += e.value; w.last = e.startTime; }
    else { w.sum = e.value; w.first = e.startTime; w.last = e.startTime; }
    if (w.sum > seg.cls) seg.cls = w.sum;
  });

  const onEvent = (e) => {
    if (!e.interactionId || e.startTime < seg.startRel) return;
    const prev = seg._int.get(e.interactionId) || 0;
    if (e.duration > prev) seg._int.set(e.interactionId, e.duration);
  };
  observe('event', onEvent, { durationThreshold: 16 });
  observe('first-input', onEvent);

  observe('longtask', (e) => {
    if (e.startTime < seg.startRel) return;
    seg.longTasks++;
    seg.tbt += Math.max(0, e.duration - 50);
  });

  ['pointerdown', 'keydown'].forEach((t) => addEventListener(t, (ev) => { if (ev.isTrusted) userInput = true; }, { capture: true, once: true }));

  function readNav() {
    const n = performance.getEntriesByType('navigation')[0];
    if (!n) return;
    const act = n.activationStart || 0;
    seg.ttfb = Math.max(0, n.responseStart - act);
    seg.nav = {
      type: n.type,
      redirect: n.redirectEnd - n.redirectStart,
      dns: n.domainLookupEnd - n.domainLookupStart,
      tcp: n.connectEnd - n.connectStart,
      tls: n.secureConnectionStart > 0 ? n.connectEnd - n.secureConnectionStart : 0,
      request: n.responseStart - n.requestStart,
      download: n.responseEnd - n.responseStart,
      domInteractive: n.domInteractive,
      dcl: n.domContentLoadedEventEnd,
      load: n.loadEventEnd || null,
      status: n.responseStatus || null,
      protocol: n.nextHopProtocol || null
    };
    seg.transferSize = n.transferSize || null;
  }

  function snapshot(final) {
    if (seg.kind === 'hard') readNav();
    const ints = Array.from(seg._int.values()).sort((a, b) => b - a);
    seg.interactions = ints.length;
    seg.inp = ints.length ? ints[Math.min(ints.length - 1, Math.floor(ints.length / 50))] : null;
    seg.resources = performance.getEntriesByType('resource').filter((r) => r.startTime >= seg.startRel).length;
    seg.title = document.title.slice(0, 120);
    const out = {};
    for (const k of Object.keys(seg)) if (k[0] !== '_') out[k] = seg[k];
    out.final = !!final;
    ['ttfb', 'fcp', 'lcp', 'inp', 'tbt'].forEach((k) => { if (out[k] != null) out[k] = Math.round(out[k]); });
    out.cls = Math.round(out.cls * 10000) / 10000;
    if (out.nav) Object.keys(out.nav).forEach((k) => { if (typeof out.nav[k] === 'number') out.nav[k] = Math.round(out.nav[k]); });
    return out;
  }

  function flush(final) {
    if (!recording) return;
    send({ type: 'vitals', seg: snapshot(final) });
    dirty = false;
  }

  setInterval(() => {
    // SPA route change -> close the current segment, start a soft one
    if (location.href !== seg.url) {
      flush(true);
      seg = newSeg('soft');
      dirty = true;
    }
    if (dirty) flush(false);
  }, 1000);

  addEventListener('load', () => setTimeout(() => { dirty = true; flush(false); }, 0));
  addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(true); });
  addEventListener('pagehide', () => flush(true));
})();
