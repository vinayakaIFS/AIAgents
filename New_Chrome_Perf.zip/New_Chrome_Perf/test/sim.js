﻿// Drives the real background.js with simulated webRequest / webNavigation / content events, checks results,
// saves a baseline, then loads the real dashboard scripts.
(async function () {
  const wr = chrome.webRequest, wn = chrome.webNavigation;
  const O = 'https://ifs.app.test';
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const send = (m) => chrome.runtime.sendMessage(m);
  let seed = 7;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  let rid = 0;
  const results = [];
  const check = (name, cond, info) => results.push({ name, ok: !!cond, info: info === undefined ? '' : JSON.stringify(info) });

  function timeline(t0, reqs, extras) {
    const evs = [];
    reqs.forEach((r) => {
      const o = {};
      evs.push({ t: t0 + r[0], p: 0, fn: () => { o.id = String(++rid); wr.onBeforeRequest._fire({ requestId: o.id, tabId: 1, frameId: 0, url: r[2], type: r[3] || 'xmlhttprequest', method: r[4] || 'GET', timeStamp: t0 + r[0] }); } });
      if (r[1] != null) evs.push({ t: t0 + r[1], p: 1, fn: () => wr.onCompleted._fire({ requestId: o.id, tabId: 1, timeStamp: t0 + r[1], statusCode: r[5] || 200, fromCache: false, responseHeaders: [{ name: 'Content-Length', value: '2048' }] }) });
    });
    (extras || []).forEach((e) => evs.push({ t: t0 + e.t, p: e.p || 0, fn: e.fn }));
    evs.sort((a, b) => a.t - b.t || a.p - b.p);
    for (const e of evs) { VT = Math.max(VT, e.t); e.fn(); }
  }
  const nav = (ev, t, url) => wn[ev]._fire({ tabId: 1, frameId: 0, url, timeStamp: t, transitionType: 'link' });

  function pageLoad(t0, url, f) {
    timeline(t0, [
      [0, 300 * f, url, 'main_frame'],
      [320 * f, 700 * f, O + '/main/app.' + Math.round(rnd() * 1e6) + '.js', 'script'],
      [330 * f, 600 * f, O + '/main/app.css', 'stylesheet'],
      [1000 * f, 1400 * f, O + '/main/ifsapplications/projection/v1/Navigator.svc/NavEntries?$select=Label', 'xmlhttprequest'],
      [1500 * f, 1800 * f, O + "/main/ifsapplications/projection/v1/Context.svc/User(Id='ALAIN')", 'fetch']
    ], [
      { t: 0, p: -1, fn: () => nav('onBeforeNavigate', t0, url) },
      { t: 300 * f + 1, p: 2, fn: () => nav('onCommitted', t0 + 300 * f + 1, url) },
      { t: 950 * f, p: 2, fn: () => nav('onDOMContentLoaded', t0 + 950 * f, url) },
      { t: 1500 * f, p: 2, fn: () => nav('onCompleted', t0 + 1500 * f, url) }
    ]);
  }
  function action(t0, label, reqs, extras, msgAt) {
    timeline(t0, reqs, [{ t: msgAt || 0, p: msgAt ? 0.5 : -1, fn: () => send({ type: 'action', kind: 'click', label, ts: t0, sel: { selectors: ['#sim-' + label.length], text: label, tag: 'button', role: 'button', frame: 'top' } }) }].concat(extras || []));
  }

  async function runSession(name, k) {
    window.TAB_URL = O + '/main/ifsapplications/web/';
    VT += 60000;
    await send({ cmd: 'start', tabId: 1, url: window.TAB_URL, name });
    let t = Date.now() + 500;
    pageLoad(t, O + '/main/ifsapplications/web/', k.load);
    await sleep(200);
    send({ type: 'vitals', seg: { id: 'hard-' + name, kind: 'hard', url: O + '/main/ifsapplications/web/', title: 'IFS Cloud', startEpoch: t, ttfb: Math.round(300 * k.load), fcp: Math.round(900 * k.load), lcp: Math.round(2300 * k.load), lcpElement: 'div.lobby', cls: 0.04 * k.load, inp: 180, tbt: 150, longTasks: 3, interactions: 4, nav: { dcl: 950, load: 1500, type: 'navigate' }, resources: 5, transferSize: 18000 } });
    t += 1800 * k.load + 4000;
    for (let i = 0; i < 6; i++) {
      const j = 0.85 + rnd() * 0.3;
      window.TAB_URL = O + '/main/ifsapplications/web/';
      action(t, 'Click link "Customer Orders"', [
        [20, 20 + 400 * k.orders * j, O + '/main/ifsapplications/projection/v1/CustomerOrderHandling.svc/CustomerOrderSet?$select=OrderNo&$top=' + (50 + i)],
        [430 * k.orders * j, 900 * k.orders * j, O + "/main/ifsapplications/projection/v1/CustomerOrderHandling.svc/Reference_Customer(CustomerNo='C" + i + "')"]
      ], [{ t: 30, fn: () => wn.onHistoryStateUpdated._fire({ tabId: 1, frameId: 0, url: O + '/main/ifsapplications/web/page/CustomerOrder/List', timeStamp: t + 30 }) }]);
      await sleep(150);
      t += 900 * k.orders * j + 3000;
      window.TAB_URL = O + "/main/ifsapplications/web/page/CustomerOrder/Form;$filter=OrderNo eq '" + (1000 + i) + "'";
      // request reaches the worker before the click message (race)
      action(t, 'Click button "Save"', [[2, 2 + 700 * k.save * j, O + "/main/ifsapplications/projection/v1/CustomerOrderHandling.svc/CustomerOrderSet(OrderNo='" + (1000 + i) + "')", 'xmlhttprequest', 'PATCH'],
        [710 * k.save * j, 800 * k.save * j, O + '/main/ifsapplications/projection/v1/CustomerOrderHandling.svc/CustomerOrderSet?$filter=x']], [], 5);
      await sleep(150);
      t += 800 * k.save * j + 2500;
      action(t, 'Click div "empty"', []);
      await sleep(150);
      t += 2000;
      if (k.vitals) send({ type: 'vitals', seg: { id: 'soft-' + name + i, kind: 'soft', url: O + '/main/ifsapplications/web/page/CustomerOrder/List', title: 'Customer Orders', startEpoch: t, cls: 0.01 * (i % 3), inp: Math.round(150 * k.orders * j), tbt: Math.round(60 * k.orders), longTasks: 1, interactions: 2 } });
    }
    // click that triggers a full navigation
    window.TAB_URL = O + '/main/ifsapplications/web/';
    action(t, 'Click link "Sign out"', []);
    pageLoad(t + 50, O + '/logout', 0.5);
    await sleep(200);
    // manual transaction
    VT += 5000;
    await send({ cmd: 'manualStart', name: '99_Manual_Batch' });
    t = VT;
    timeline(t, [[100, 600, O + '/api/batch/1'], [700, 1500, O + '/api/batch/2']]);
    VT = t + 2500;
    await send({ cmd: 'manualEnd' });
    await sleep(100);
    // long-poll request should not hold the transaction
    t = VT + 1000;
    action(t, 'Click button "Live"', [[10, null, O + '/poll/longpoll'], [20, 520, O + '/api/data']]);
    VT = t + 10000;
    await sleep(1700);
    await send({ cmd: 'stop' });
  }

  await sleep(50);
  await runSession('Baseline run – 25R1', { load: 1, orders: 1, save: 1, vitals: true });
  const idx1 = await Store.listSessions();
  const s1 = await Store.getSession(idx1[0].id);
  const tx = s1.transactions;
  const byName = (n) => tx.filter((x) => x.name === n);
  check('session has 16 transactions (1 load + 6×(orders+save) + sign-out + manual + live)', tx.length === 16, tx.map((x) => x.name));
  check('all closed', tx.every((x) => x.status === 'closed'));
  check('page load = 1800 ms', tx[0].duration === 1800 && tx[0].type === 'navigation', [tx[0].name, tx[0].duration]);
  check('page load has 5 requests', tx[0].reqCount === 5, tx[0].reqCount);
  const orders = byName('Click link "Customer Orders" @ /main/ifsapplications/web');
  check('orders action named and counted 6×', orders.length === 6, tx.map((x) => x.name));
  check('orders action has 2 requests + routeTo', orders[0] && orders[0].reqCount === 2 && orders[0].routeTo === '/main/ifsapplications/web/page/CustomerOrder/List', orders[0] && [orders[0].reqCount, orders[0].routeTo]);
  const save = byName('Click button "Save" @ /main/ifsapplications/web/page/CustomerOrder/Form');
  check('save action: matrix params stripped, 6×', save.length === 6, tx.map((x) => x.name));
  check('save adopted the request that arrived before the click message', save.every((x) => x.reqCount === 2), save.map((x) => x.reqCount));
  check('no empty actions kept', !tx.some((x) => x.name.includes('empty')));
  const so = tx.find((x) => x.name.startsWith('Click link "Sign out"'));
  check('sign-out merged with navigation', so && so.type === 'navigation' && so.name === 'Click link "Sign out" → /logout' && so.duration === 950, so && [so.name, so.type, so.duration]);
  const man = byName('99_Manual_Batch')[0];
  check('manual = 1500 ms, 2 requests', man && man.duration === 1500 && man.reqCount === 2, man && [man.duration, man.reqCount]);
  const live = byName('Click button "Live" @ /main/ifsapplications/web')[0];
  check('long-poll excluded: live = 520 ms', live && live.duration === 520 && live.requests.some((r) => r.long), live && [live.duration, live.requests.map((r) => r.long)]);
  check('no unattributed requests', s1.unattributed.length === 0, s1.unattributed.map((r) => r.url));
  check('vitals stored', Object.keys(s1.vitals).length === 7, Object.keys(s1.vitals).length);
  check('seq numbers 1..16', tx.map((x) => x.seq).join() === Array.from({ length: 16 }, (_, i) => i + 1).join(), tx.map((x) => x.seq));

  const b = PerfStats.buildBaseline('Release 25R1 baseline', [s1]);
  await Store.saveBaseline(b);
  await Store.set('activeBaseline', b.id);

  await runSession('Run 2 – 25R2 build 3', { load: 1.05, orders: 1.45, save: 0.6, vitals: true });
  const idx2 = await Store.listSessions();
  const s2 = await Store.getSession(idx2.find((x) => x.name.startsWith('Run 2')).id);
  const cmp = PerfStats.compare(PerfStats.baselineStats(b).transactions, PerfStats.aggregateTransactions(s2.transactions), { metric: 'p95', thresholdPct: 10, thresholdMs: 50 });
  check('compare: orders degraded, save improved, load unchanged', cmp.rows.find((r) => r.name.startsWith('Click link "Customer')).status === 'degraded' &&
    cmp.rows.find((r) => r.name.startsWith('Click button "Save"')).status === 'improved' && cmp.rows.find((r) => r.name.startsWith('Load')).status === 'unchanged', cmp.counts);
  check('percentile nearest-rank', PerfStats.percentile([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 95) === 10 && PerfStats.percentile([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 50) === 5);

  // ---------- flows: auto-saved recordings + rerun ----------
  const flowsIdx = await Store.listFlows();
  check('every recording auto-saved as a flow', flowsIdx.length === 2, flowsIdx.map((f) => f.name));
  const flow = await Store.getFlow(flowsIdx.find((f) => f.name.startsWith('Baseline')).id);
  check('flow has 23 steps (start + 6x(orders, save, empty) + sign-out + manual start/end + live)', flow.steps.length === 23, flow.steps.map((x) => x.kind + ':' + (x.label || x.name || x.url)));
  check('steps carry recorded transaction names', flow.steps[1].txName === 'Click link "Customer Orders" @ /main/ifsapplications/web' && flow.steps[3].txName === null, [flow.steps[1].txName, flow.steps[3].txName]);
  check('flow keeps the recording as first run', flow.runs.length === 1 && flow.runs[0].kind === 'recorded');

  // simulated application behaviour for rerun steps
  let it = 0;
  window.FIND = () => true;
  window.ON_RELOAD = () => { window.TAB_URL = O + '/main/ifsapplications/web/'; pageLoad(Date.now() + 5, O + '/main/ifsapplications/web/', 1.1); };
  window.ON_NAVIGATE = (url) => { window.TAB_URL = url; pageLoad(Date.now() + 5, url, 1.1); };
  window.ON_ACT = (st) => {
    const t = Date.now() + 1;
    const k = 1.5;
    if (st.label.startsWith('Click link "Customer Orders"')) {
      it++;
      timeline(t, [[20, 20 + 400 * k, O + '/main/ifsapplications/projection/v1/CustomerOrderHandling.svc/CustomerOrderSet?$select=OrderNo&$top=5' + it],
        [430 * k, 900 * k, O + '/main/ifsapplications/projection/v1/CustomerOrderHandling.svc/Reference_Customer(CustomerNo=R' + it + ')']]);
      window.TAB_URL = O + '/main/ifsapplications/web/page/CustomerOrder/Form;$filter=OrderNo eq 9';
    } else if (st.label.startsWith('Click button "Save"')) {
      timeline(t, [[2, 2 + 700 * 0.8, O + '/main/ifsapplications/projection/v1/CustomerOrderHandling.svc/CustomerOrderSet(OrderNo=9)', 'xmlhttprequest', 'PATCH'],
        [710 * 0.8, 800 * 0.8, O + '/main/ifsapplications/projection/v1/CustomerOrderHandling.svc/CustomerOrderSet?$filter=x']]);
      window.TAB_URL = O + '/main/ifsapplications/web/';
    } else if (st.label.startsWith('Click link "Sign out"')) {
      pageLoad(t + 50, O + '/logout', 0.5);
    } else if (st.label.startsWith('Click button "Live"')) {
      timeline(t, [[10, null, O + '/poll/longpoll2'], [20, 600, O + '/api/data']]);
      VT = t + 10000;
    }
  };
  const settingsNow = await Store.getSettings();
  await Store.saveSettings(Object.assign(settingsNow, { replayMaxThinkMs: 30 }));
  const startRes = await send({ cmd: 'runFlow', flowId: flow.id, opts: { iterations: 2, think: 'recorded' } });
  check('rerun started', startRes && startRes.ok, startRes);
  const tWait = performance.now();
  for (;;) {
    await sleep(500);
    const st = await Store.get('replayState', null);
    if (st && st.active === false) break;
    if (performance.now() - tWait > 150000) break;
  }
  const rs = await Store.get('replayState', null);
  check('rerun finished ok', rs && rs.status === 'ok', rs);
  const flow2 = await Store.getFlow(flow.id);
  const run = flow2.runs.find((r) => r.kind === 'rerun');
  check('rerun stored on the flow (46 steps ok)', flow2.runs.length === 2 && run && run.status === 'ok' && run.stepsOk === 46, run);
  const rsess = run && await Store.getSession(run.sessionId);
  const rtx = rsess ? rsess.transactions : [];
  check('rerun session marked as rerun and linked', rsess && rsess.flowId === flow.id && rsess.replay && rsess.replay.iterations === 2);
  check('rerun has 2x the recorded transactions (32)', rtx.length === 32, rtx.map((x) => x.name + ' ' + x.duration));
  const rcmp = PerfStats.compare(PerfStats.aggregateTransactions(s1.transactions), PerfStats.aggregateTransactions(rtx), { metric: 'p95', thresholdPct: 10, thresholdMs: 50 });
  check('rerun names match the recording (no new / missing)', rcmp.counts.new === 0 && rcmp.counts.missing === 0, rcmp.rows.filter((r) => r.status === 'new' || r.status === 'missing').map((r) => r.name));
  check('rerun timings: orders degraded, save improved', rcmp.rows.find((r) => r.name.startsWith('Click link "Customer')).status === 'degraded' &&
    rcmp.rows.find((r) => r.name.startsWith('Click button "Save"')).status === 'improved', rcmp.rows.map((r) => r.name + ' ' + r.status + ' ' + Math.round(r.cv || 0)));
  check('rerun recorded no new steps', rsess && !(rsess.steps || []).length);

  window.__results = results;
  console.log('TEST RESULTS', results.filter((r) => !r.ok).length ? 'FAIL' : 'PASS', JSON.stringify(results, null, 1));

  for (const src of window.DASH_SCRIPTS) {
    await new Promise((res) => { const s = document.createElement('script'); s.src = src; s.onload = res; document.body.appendChild(s); });
  }
})();
