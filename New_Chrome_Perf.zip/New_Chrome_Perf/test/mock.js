// Mock chrome.* for driving background.js + dashboard in a normal page. Virtual clock via Date.now.
(function () {
  window.VT = Date.parse('2026-11-11T09:00:00Z');
  const realNow = Date.now.bind(Date);
  Date.now = () => window.VT;
  window.realNow = realNow;
  window.importScripts = function () {};
  const ev = () => { const ls = []; return { addListener: (f) => ls.push(f), removeListener: (f) => { const i = ls.indexOf(f); if (i >= 0) ls.splice(i, 1); }, _fire: (...a) => ls.forEach((f) => f(...a)), _ls: ls }; };
  const mem = {};
  const clone = (v) => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));
  const onChanged = ev();
  window.__mem = mem;
  window.chrome = {
    storage: {
      local: {
        get: async (k) => {
          const out = {};
          const keys = k == null ? Object.keys(mem) : Array.isArray(k) ? k : typeof k === 'string' ? [k] : Object.keys(k);
          keys.forEach((key) => { if (key in mem) out[key] = clone(mem[key]); });
          return out;
        },
        set: async (o) => {
          const ch = {};
          for (const [k, v] of Object.entries(o)) { ch[k] = { oldValue: mem[k], newValue: clone(v) }; mem[k] = clone(v); }
          setTimeout(() => onChanged._fire(ch, 'local'), 0);
        },
        remove: async (k) => { (Array.isArray(k) ? k : [k]).forEach((x) => delete mem[x]); },
        getBytesInUse: async () => JSON.stringify(mem).length
      },
      onChanged
    },
    runtime: {
      onMessage: ev(),
      sendMessage: (msg) => new Promise((res) => {
        const sender = msg.__sender || { tab: { id: 1, url: window.TAB_URL || 'https://app.test/' } };
        chrome.runtime.onMessage._ls.forEach((f) => f(msg, sender, res));
      }),
      getURL: (p) => p,
      getPlatformInfo: (cb) => cb && cb({})
    },
    webRequest: { onBeforeRequest: ev(), onCompleted: ev(), onErrorOccurred: ev() },
    webNavigation: { getAllFrames: async () => [{ frameId: 0, url: window.TAB_URL }], onBeforeNavigate: ev(), onCommitted: ev(), onDOMContentLoaded: ev(), onCompleted: ev(), onErrorOccurred: ev(), onHistoryStateUpdated: ev(), onReferenceFragmentUpdated: ev() },
    tabs: {
      get: async (id) => ({ id, status: 'complete', url: window.TAB_URL || 'https://app.test/' }),
      onRemoved: ev(),
      reload: (id, o) => { setTimeout(() => window.ON_RELOAD && window.ON_RELOAD(o), 0); },
      create: async (o) => ({ id: 1, url: o && o.url }),
      update: async (id, o) => { setTimeout(() => window.ON_NAVIGATE && window.ON_NAVIGATE(o.url), 0); return { id }; },
      remove: async () => {},
      query: async () => [{ id: 1, url: 'https://app.test/' }],
      sendMessage: async (id, msg) => {
        if (msg.cmd === 'txperf-locate') return { found: !!(msg.step.sel && window.FIND && window.FIND(msg.step)) };
        if (msg.cmd === 'txperf-act') { setTimeout(() => window.ON_ACT && window.ON_ACT(msg.step), 0); return { ok: true }; }
        return null;
      }
    },
    action: { setBadgeText() {}, setBadgeBackgroundColor() {} },
    alarms: { create() {}, clear() {}, onAlarm: ev() },
    scripting: { executeScript: async () => {} }
  };
})();
